"""Observed compressor starts and CO/CWU heating phases, independent of Smart.

No control commands are sent here.  A heating phase may begin when the valve
changes without a compressor start.  Cycling is inferred from a CO water
overshoot and uninterrupted demand; it is not a manufacturer stop-reason code.
"""

from dataclasses import dataclass
import json
import math
import os
from pathlib import Path
import tempfile
import threading
import time


def _finite(value):
    if isinstance(value, bool):
        return None
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return value if math.isfinite(value) else None


@dataclass(frozen=True)
class CycleObservation:
    timestamp: float
    sample_id: object
    running: object = None
    circuit: object = None
    heat_demand: object = None
    pump_on: object = None
    twi: object = None
    two: object = None
    target_ch: object = None
    special: bool = False
    defrost: object = None
    valid: bool = True
    sample_time: object = None
    reason: str = ''


class CompressorCycleStats:
    """Bounded persistent history, with explicit gaps and no invented starts.

    State transitions need two distinct coherent observations.  After a process
    restart or a measurement gap, the first sample establishes a new baseline.
    Stored events survive restart, while process-local monotonic stamps do not.
    """

    COUNTERS = ('compressor_starts', 'starts_co', 'starts_cwu', 'starts_other',
                'co_cycles', 'cwu_cycles', 'cycling_restarts', 'defrosts')
    WINDOWS = (('24h', 86400), ('7d', 7 * 86400))

    def __init__(self, path, *, retention_days=30, max_events=20000,
                 max_bytes=2 * 1024 * 1024, checkpoint_s=300,
                 max_gap_s=45, cycling_margin_c=5.0):
        if retention_days < 7 or max_events < 4 or max_bytes < 4096:
            raise ValueError('Invalid cycle-history limits')
        self.path = Path(path)
        self.retention_s = float(retention_days) * 86400
        self.max_events, self.max_bytes = int(max_events), int(max_bytes)
        self.checkpoint_s, self.max_gap_s = float(checkpoint_s), float(max_gap_s)
        self.cycling_margin_c = float(cycling_margin_c)
        self._lock = threading.RLock()
        self.events, self.coverage = [], []
        self.started_at = self.last_sample_at = self.truncated_before = None
        self._read_error = self._write_error = ''
        self._last_attempt = None
        self._dirty = False
        self._last_id = self._last_mono = self._last_wall = None
        self._last_certain_mono = self._last_certain_wall = None
        self._clock_floor = None
        self._fresh = False
        self._reason = ''
        self._running = self._circuit = self._phase = None
        self._run_pending = self._phase_pending = None
        self._run_start = None
        self._thermal_stop = None
        self._thermal_target = None
        self._recent_co = []
        self._defrost = None
        self._defrost_pending = None
        self._load()

    def _load(self):
        try:
            if not self.path.exists() and not self.path.is_symlink():
                return
            if self.path.is_symlink() or not self.path.is_file():
                raise ValueError('Nieprawidlowy plik historii cykli')
            if self.path.stat().st_size > self.max_bytes:
                raise ValueError('Plik historii cykli przekracza limit rozmiaru')
            raw = json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(raw, dict) or raw.get('version') != 1:
                raise ValueError('Nieznany format historii cykli')
            events, coverage = raw.get('events'), raw.get('coverage')
            if not isinstance(events, list) or not isinstance(coverage, list):
                raise ValueError('Nieprawidlowa historia cykli')
            previous = None
            for event in events:
                if not isinstance(event, dict):
                    raise ValueError('Nieprawidlowe zdarzenie cyklu')
                stamp = _finite(event.get('t'))
                if (stamp is None or event.get('kind') not in ('start', 'phase', 'stop', 'defrost') or
                        (previous is not None and stamp < previous)):
                    raise ValueError('Nieprawidlowa kolejnosc zdarzen cykli')
                if event.get('circuit') not in ('co', 'cwu', 'other'):
                    raise ValueError('Nieprawidlowy obieg w historii cykli')
                previous = stamp
            previous_end = None
            for segment in coverage:
                if not isinstance(segment, list) or len(segment) != 2:
                    raise ValueError('Nieprawidlowe pokrycie historii cykli')
                start, end = map(_finite, segment)
                if (start is None or end is None or end < start or
                        (previous_end is not None and start < previous_end)):
                    raise ValueError('Nieprawidlowa kolejnosc pokrycia historii')
                previous_end = end
            for key in ('started_at', 'last_sample_at', 'truncated_before'):
                value = raw.get(key)
                if value is not None and _finite(value) is None:
                    raise ValueError('Nieprawidlowy czas historii cykli')
                setattr(self, key, _finite(value))
            if ((self.started_at is not None and self.last_sample_at is not None and
                 self.started_at > self.last_sample_at) or
                    (previous is not None and (self.last_sample_at is None or
                                              previous > self.last_sample_at))):
                raise ValueError('Niespojny czas historii cykli')
            self.events, self.coverage = events, coverage
            self._clock_floor = self.last_sample_at
        except Exception as exc:
            # Do not overwrite a damaged existing file with empty counters.
            self._read_error = str(exc)
            self.events, self.coverage = [], []
            self.started_at = self.last_sample_at = self.truncated_before = None

    def _break(self, reason='Brak ciaglosci odczytow'):
        self._fresh = False
        self._reason = reason
        self._running = self._circuit = self._phase = None
        self._run_pending = self._phase_pending = None
        self._run_start = self._thermal_stop = None
        self._thermal_target = None
        self._recent_co = []
        self._defrost = self._defrost_pending = None
        self._last_certain_mono = self._last_certain_wall = None

    @staticmethod
    def _category(obs):
        return obs.circuit if not obs.special and obs.circuit in ('co', 'cwu') else 'other'

    @staticmethod
    def _normal_co(obs):
        return (obs.circuit == 'co' and not obs.special and
                obs.heat_demand is True and obs.pump_on is True)

    @staticmethod
    def _details(obs):
        result = {}
        for key in ('twi', 'two', 'target_ch'):
            value = _finite(getattr(obs, key))
            if value is not None:
                result[key] = round(value, 2)
        return result

    def _event(self, kind, obs, circuit, **extra):
        event = dict(t=obs.timestamp, kind=kind, circuit=circuit)
        event.update(self._details(obs))
        event.update(extra)
        self.events.append(event)
        self._dirty = True

    def _thermal_observation(self, obs, mono, record=True):
        if not self._normal_co(obs):
            self._thermal_stop = None
            self._thermal_target = None
            self._recent_co = []
            return
        two, target = _finite(obs.two), _finite(obs.target_ch)
        if (two is None or target is None or not -10 <= two <= 70 or
                not 20 <= target <= 55):
            self._thermal_stop = self._thermal_target = None
            self._recent_co = []
            return
        if self._thermal_target is not None and target != self._thermal_target:
            self._thermal_stop = None
            self._recent_co = []
        self._thermal_target = target
        if not record:
            return
        self._recent_co = [item for item in self._recent_co if 0 <= mono - item[0] <= 60]
        self._recent_co.append((mono, two - target))

    def _phase_observation(self, obs):
        if obs.special:
            # Defrost/protection does not create another CO phase on return.
            self._phase_pending = None
            return
        circuit = obs.circuit if obs.circuit in ('co', 'cwu', 'other') else None
        if circuit is None or circuit == self._phase:
            self._phase_pending = None
            return
        if self._phase_pending is None or self._phase_pending[0] != circuit:
            self._phase_pending = (circuit, obs)
            return
        first = self._phase_pending[1]
        if circuit in ('co', 'cwu'):
            self._event('phase', first, circuit)
        self._phase = circuit
        self._phase_pending = None

    def _confirm_transition(self, first, obs, mono):
        old_phase = self._phase
        self._running = obs.running
        self._run_pending = self._phase_pending = None
        if obs.running:
            circuit = self._category(first)
            if circuit != self._category(obs):
                circuit = 'other'
            cycling = bool(circuit == 'co' and self._thermal_stop and
                           self._normal_co(first) and self._normal_co(obs))
            stop = self._thermal_stop
            extra = {'cycling': cycling}
            if cycling:
                extra['stop_margin'] = round(stop['margin'], 2)
                extra['pause_s'] = round(max(0, first.timestamp - stop['t']), 1)
            self._event('start', first, circuit, **extra)
            self._run_start = first.timestamp
            self._phase = None
            if circuit in ('co', 'cwu'):
                self._event('phase', first, circuit)
                self._phase = circuit
            self._thermal_stop = None
        else:
            circuit = old_phase if old_phase in ('co', 'cwu') else 'other'
            margin = max((entry[1] for entry in self._recent_co), default=None)
            candidate = (circuit == 'co' and self._normal_co(first) and
                         self._normal_co(obs) and margin is not None and
                         margin >= self.cycling_margin_c)
            duration = (None if self._run_start is None else
                        round(max(0, first.timestamp - self._run_start), 1))
            self._event('stop', first, circuit, duration_s=duration,
                        suspected_thermal_stop=bool(candidate))
            self._thermal_stop = (dict(t=first.timestamp, margin=margin) if candidate else None)
            self._phase = self._run_start = None

    def _trim(self, now):
        cutoff = now - self.retention_s
        self.events = [event for event in self.events if event['t'] >= cutoff]
        self.coverage = [[max(start, cutoff), end] for start, end in self.coverage if end >= cutoff]
        if len(self.events) > self.max_events:
            removed = self.events[:-self.max_events]
            self.events = self.events[-self.max_events:]
            self._truncate_at(removed[-1]['t'])
        # Bound gap metadata even if a device spends weeks reconnecting.
        if len(self.coverage) > self.max_events:
            self._truncate_at(self.coverage[-self.max_events - 1][1])
            self.coverage = self.coverage[-self.max_events:]

    def _truncate_at(self, stamp):
        self.truncated_before = max(stamp, self.truncated_before or stamp)
        self.coverage = [[max(start, stamp), end] for start, end in self.coverage if end > stamp]

    def _encoded(self):
        raw = dict(version=1, started_at=self.started_at, last_sample_at=self.last_sample_at,
                   truncated_before=self.truncated_before, events=self.events, coverage=self.coverage)
        return (json.dumps(raw, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')

    def _persist(self, now, mono, force=False):
        if self._read_error or not self._dirty:
            return
        retry_wait = 60 if self._write_error else self.checkpoint_s
        if not force and self._last_attempt is not None and mono - self._last_attempt < retry_wait:
            return
        self._last_attempt = mono
        temporary = None
        try:
            self._trim(now)
            encoded = self._encoded()
            while len(encoded) > self.max_bytes:
                if self.events:
                    count = max(1, len(self.events) // 8)
                    self._truncate_at(self.events[count - 1]['t'])
                    del self.events[:count]
                elif len(self.coverage) > 1:
                    self._truncate_at(self.coverage[max(1, len(self.coverage) // 2) - 1][1])
                else:
                    raise OSError('Brak miejsca w ograniczonej historii cykli')
                encoded = self._encoded()
            self.path.parent.mkdir(parents=True, exist_ok=True)
            if self.path.is_symlink():
                raise OSError('Nieprawidlowy plik historii cykli')
            descriptor, temporary = tempfile.mkstemp(prefix='.compressor-cycles-', dir=str(self.path.parent))
            with os.fdopen(descriptor, 'wb') as stream:
                os.fchmod(stream.fileno(), 0o600)
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            descriptor = os.open(str(self.path.parent), os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
            self._dirty = False
            self._write_error = ''
        except (OSError, ValueError) as exc:
            self._write_error = str(exc)
        finally:
            if temporary is not None and os.path.exists(temporary):
                try:
                    os.unlink(temporary)
                except OSError:
                    pass

    def observe(self, obs):
        with self._lock:
            stamp = _finite(obs.timestamp)
            mono = _finite(obs.sample_time) if obs.sample_time is not None else stamp
            now = stamp if stamp is not None else time.time()
            if self._read_error:
                return self._summary(now)
            if (stamp is None or mono is None or not obs.valid or
                    not isinstance(obs.sample_id, int) or isinstance(obs.sample_id, bool)):
                self._break(obs.reason or 'Brak wiarygodnych odczytow')
                return self._summary(now)
            if self._clock_floor is not None and stamp < self._clock_floor:
                self._break('Cofniecie zegara; oczekiwanie na wiarygodny czas')
                return self._summary(now)
            if self._last_id == obs.sample_id:
                # R141/GPIO may change before another R241 frequency frame.
                # Such a contradiction cancels thermal inference, but cannot
                # advance a run/phase confirmation or add coverage.
                self._thermal_observation(obs, mono, record=False)
                if self._phase_pending is not None and (obs.special or
                        obs.circuit != self._phase_pending[0]):
                    self._phase_pending = None
                if self._last_wall is not None and stamp - self._last_wall > self.max_gap_s:
                    self._break('Brak nowych odczytow')
                return self._summary(now)
            if self._last_mono is not None and (mono <= self._last_mono or
                                               obs.sample_id < self._last_id):
                self._break('Przerwana kolejnosc odczytow')
            if self._last_mono is not None and mono - self._last_mono > self.max_gap_s:
                self._break('Przerwa w odczytach')
            if self._last_wall is not None and stamp < self._last_wall:
                self._clock_floor = self._last_wall
                self._break('Cofniecie zegara; oczekiwanie na wiarygodny czas')
                return self._summary(now)
            if self._last_wall is not None and stamp - self._last_wall > self.max_gap_s:
                self._break('Przerwa w odczytach lub zmiana zegara')
            self._last_id, self._last_mono, self._last_wall = obs.sample_id, mono, stamp
            self._clock_floor = stamp
            self.last_sample_at = stamp
            was_fresh = self._fresh
            self._thermal_observation(obs, mono)
            if not isinstance(obs.running, bool):
                self._run_pending = self._phase_pending = None
                if self._last_certain_mono is None or mono - self._last_certain_mono > self.max_gap_s:
                    self._break('Oczekiwanie na zgodny stan sprezarki')
                elif self.coverage:
                    self.coverage[-1][1] = stamp
                    self._dirty = True
                self._persist(stamp, mono)
                return self._summary(now)
            self._last_certain_mono, self._last_certain_wall = mono, stamp
            if self.started_at is None:
                self.started_at = stamp
            if not was_fresh:
                self.coverage.append([stamp, stamp])
                self._running = obs.running
                self._defrost = obs.defrost if isinstance(obs.defrost, bool) else None
                self._defrost_pending = None
                self._phase = self._category(obs) if obs.running else None
                self._run_pending = self._phase_pending = None
                self._run_start = self._thermal_stop = None
                self._fresh = True
                self._reason = ''
                self._dirty = True
                self._circuit = obs.circuit
                self._persist(stamp, mono, force=self._last_attempt is None)
                return self._summary(now)
            self.coverage[-1][1] = stamp
            self._dirty = True
            before = len(self.events)
            if isinstance(obs.defrost, bool):
                if self._defrost is None:
                    self._defrost = obs.defrost
                elif obs.defrost == self._defrost:
                    self._defrost_pending = None
                elif self._defrost_pending == obs.defrost:
                    if obs.defrost:
                        self._event('defrost', obs, obs.circuit if obs.circuit in ('co', 'cwu') else 'other')
                    self._defrost = obs.defrost
                    self._defrost_pending = None
                else:
                    self._defrost_pending = obs.defrost
            else:
                self._defrost = self._defrost_pending = None
            if obs.running != self._running:
                if self._run_pending is None or self._run_pending.running != obs.running:
                    self._run_pending = obs
                    self._phase_pending = None
                else:
                    self._confirm_transition(self._run_pending, obs, mono)
            else:
                self._run_pending = None
                if obs.running:
                    self._phase_observation(obs)
            self._circuit = obs.circuit
            self._reason = ''
            self._persist(stamp, mono, force=len(self.events) != before and not self._write_error)
            return self._summary(now)

    def _summary(self, now):
        error = self._read_error or self._write_error
        fresh = (self._fresh and self.last_sample_at is not None and
                 0 <= now - self.last_sample_at <= self.max_gap_s)
        status = 'error' if error else ('waiting' if self.started_at is None else
                                       'ok' if fresh else 'stale')
        segments = [list(pair) for pair in self.coverage]
        if fresh and segments:
            segments[-1][1] = max(segments[-1][1], now)
        windows = {}
        for name, seconds in self.WINDOWS:
            cutoff = now - seconds
            counts = dict.fromkeys(self.COUNTERS, 0)
            for event in self.events:
                if not cutoff < event['t'] <= now:
                    continue
                if event['kind'] == 'start':
                    counts['compressor_starts'] += 1
                    counts['starts_' + event['circuit']] += 1
                    if event.get('cycling') is True:
                        counts['cycling_restarts'] += 1
                elif event['kind'] == 'defrost':
                    counts['defrosts'] += 1
                elif event['kind'] == 'phase' and event['circuit'] in ('co', 'cwu'):
                    counts[event['circuit'] + '_cycles'] += 1
            observed = sum(max(0, min(end, now) - max(start, cutoff)) for start, end in segments)
            observed = min(float(seconds), observed)
            complete = (observed >= seconds - .001 and
                        (self.truncated_before is None or self.truncated_before <= cutoff))
            counts.update(observed_seconds=round(observed, 1),
                          coverage_fraction=round(observed / seconds, 6), complete=complete)
            if error:
                counts.update(dict.fromkeys(self.COUNTERS, None))
            windows[name] = counts
        return dict(available=not bool(error), status=status, error=error or None,
                    reason=self._reason, started_at=self.started_at,
                    last_sample_at=self.last_sample_at,
                    history_truncated=(self.truncated_before is not None and
                                       self.truncated_before > now - self.retention_s),
                    retention_days=int(self.retention_s / 86400),
                    current=dict(running=self._running if fresh else None,
                                 circuit=self._circuit if fresh else None), windows=windows)

    def summary(self, now=None):
        with self._lock:
            stamp = time.time() if now is None else _finite(now)
            if stamp is None:
                raise ValueError('Invalid summary time')
            return self._summary(stamp)
