"""Observed-state controller for HaierPi's automatic presets and FLimit.

This module contains conservative engineering heuristics, not Haier's native
stop/restart law or a learned model. ``Two - target_ch`` is an observed margin;
A03 is deliberately NOT added to it. Quiet + FLimit denotes a control setting,
not a verified minimum compressor frequency. Neither frequency channel is
assumed to be the measured one: any valid positive channel means running.
Frequency is observed only to distinguish a running compressor from a stop;
the available commands select a preset or enable/disable FLimit, never Hz.

Each decision consumes a distinct, recent monotonic water sample. Fast Two
trends use about 60 seconds; slow water trends use 3--5 minutes. Forecasts
extend at most one minute and never extrapolate a change in the CH target.
Monitoring and action intervals are independent.

Callback True means that the command was accepted. Subsequent reported state
is required before treating a stage as established; the GPIO status still
does not establish physical relay operation or hydraulic flow.
"""

from collections import deque
import logging
import math
import threading
import time

LOGGER = logging.getLogger(__name__)


def _number(value, low=None, high=None):
    try:
        value = float(str(value).strip().replace(',', '.'))
    except (TypeError, ValueError, OverflowError):
        return None
    if not math.isfinite(value):
        return None
    if low is not None and value < low:
        return None
    if high is not None and value > high:
        return None
    return value


class SmartAdaptiveDrive:
    """Single-step, reversible stage decisions from fresh CO observations."""

    # Kolejnosc od najnizszej do najwyzszej dostepnej mocy.
    # Turbo+FLimit = zmierzony limit 45 Hz; Quiet+FLimit = 40 Hz.
    STAGES = (('quiet', True), ('turbo', True),
              ('quiet', False), ('eco', False), ('turbo', False))
    LEVELS = ('quiet', 'eco', 'turbo')
    SAMPLE_MAX_AGE = 30.0
    HISTORY_MAX_GAP = 90.0
    PUMP_SETTLE = 60.0
    CONFIRM_SECONDS = 30.0
    RISK_ACTION_GAP = 60.0
    RETRY_GAP = 30.0
    STATE_CONFIRM_TIMEOUT = 90.0
    FLIMIT_MIN_HOLD = 600.0
    DEFICIT_CONFIRM = 300.0

    def __init__(self):
        self.lock = threading.RLock()
        self.last_action = None
        self.last_attempt = None
        self.last_now = None
        self.last_report = None
        self._clear_context()

    def _clear_context(self):
        self.samples = deque(maxlen=256)
        self.room_samples = deque(maxlen=256)
        self.last_sample = None
        self.last_water = None
        self.pump_since = None
        self.running = None
        self.cycle_start = None
        self.thermal_stop = None
        self.warm_restart = False
        self.last_stage = None
        self.flimit_since = None
        self.min_stage_since = None
        self.candidate = None
        self.candidate_since = None
        self.deficit_since = None
        self.pending_action = None
        self.composite_retry = None  # niedokonczona bezpieczna zmiana dwoch sterowan
        self.release_plan = None
        self.a03_blocked_until = None
        self.last_risk = None

    def reset(self):
        """Discard observations and cycle memory, preserving action cooldowns."""
        with self.lock:
            self._clear_context()

    @staticmethod
    def _clamp(value, low, high):
        return max(low, min(high, value))

    @staticmethod
    def _slope(samples, index):
        """OLS slope in degrees/minute; samples include monotonic time at [0]."""
        if len(samples) < 2:
            return 0.0
        start = samples[0][0]
        xs = [(row[0] - start) / 60.0 for row in samples]
        ys = [row[index] for row in samples]
        xm, ym = sum(xs) / len(xs), sum(ys) / len(ys)
        den = sum((x - xm) ** 2 for x in xs)
        if den < 1e-9:
            return 0.0
        return sum((x - xm) * (y - ym) for x, y in zip(xs, ys)) / den

    def _trend(self, sample_time, seconds, index, minimum_span, same_target=False):
        rows = [s for s in self.samples if sample_time - s[0] <= seconds + .001]
        if same_target and rows:
            # A target step changes the actual margin immediately, but it is
            # not a water-temperature slope to project into the future.
            target = rows[-1][3]
            first = len(rows) - 1
            while first > 0 and abs(rows[first - 1][3] - target) < .01:
                first -= 1
            rows = rows[first:]
        if len(rows) < 3 or rows[-1][0] - rows[0][0] < minimum_span:
            return None
        return self._slope(rows, index)

    def _result(self, now, status, reason, force=False, **extra):
        due = (self.last_report is None or now - self.last_report >= 60)
        evaluated = bool(force or due)
        if evaluated:
            self.last_report = now
        result = dict(status=status, reason=reason, evaluated=evaluated,
                      fresh_sample=False, inhibit_a03=False, a03_allowed=False,
                      phase='pauza', cycle_event=None, proposal=None,
                      change_ack=None, command_sent=False)
        result.update(extra)
        return result

    def _pause(self, now, reason, status='pauza'):
        self._clear_context()
        return self._result(now, status, reason, inhibit_a03=True)

    def tick(self, cfg, snap, set_mode, set_flimit, set_stage=None, a03_owned=False, now=None):
        """Observe once; never invoke either callback for a duplicate sample."""
        clock = time.monotonic() if now is None else _number(now, 0)
        if clock is None:
            with self.lock:
                self._clear_context()
                return dict(status='pauza', reason='Nieprawidlowy zegar monotoniczny',
                            evaluated=False, fresh_sample=False, inhibit_a03=True,
                            a03_allowed=False, phase='pauza', cycle_event=None,
                            proposal=None, change_ack=None, command_sent=False)
        with self.lock:
            try:
                return self._tick(cfg, snap, set_mode, set_flimit, set_stage,
                                  bool(a03_owned), clock)
            except Exception:
                LOGGER.exception('Smart Drive: blad analizy lub komendy')
                # A thrown callback is an attempted write too. Retry limits
                # survive context resets and transient exceptions.
                self.last_attempt = clock
                self._clear_context()
                return self._result(clock, 'blad', 'Blad Smart; sterowanie wstrzymane',
                                    force=True, change_ack=False, inhibit_a03=True)

    def _tick(self, cfg, snap, set_mode, set_flimit, set_stage, a03_owned, now):
        if self.last_now is not None and now < self.last_now:
            self.last_now = now
            self.last_action = now if self.last_action is not None else None
            self.last_attempt = now if self.last_attempt is not None else None
            self.last_report = None
            return self._pause(now, 'Cofniecie zegara; zbieranie nowej historii')
        self.last_now = now
        if not cfg.enabled or not snap.classic_enabled:
            return self._pause(now, 'Smart lub klasyczna Delta nieaktywna', 'wylaczony')
        if not snap.ready:
            return self._pause(now, snap.reason or 'Niepotwierdzone warunki CO')
        if not snap.preset_auto or not snap.auto_flimit:
            return self._pause(now, 'Reczne sterowanie trybem lub FLimit')
        if getattr(snap, 'pump_on', None) is not True:
            return self._pause(now, 'Brak potwierdzenia pracy obiegu')
        if getattr(snap, 'heat_demand', None) is not True:
            return self._pause(now, 'Brak potwierdzonego zapotrzebowania CO')
        if getattr(snap, 'frequency_coherent', True) is False:
            return self._pause(now, 'Niespojne odczyty czestotliwosci')
        mode = str(snap.mode).strip().lower()
        if mode not in self.LEVELS:
            return self._pause(now, 'Nieznany tryb pompy')
        stage = (mode, bool(snap.flimit_on))
        if stage not in self.STAGES:
            return self._pause(now, 'Niestandardowe polaczenie trybu i FLimit')
        second = getattr(snap, 'compressor_hz_second', None)
        if second is None:
            second = getattr(snap, 'compressor_set_hz', None)
        channels = [_number(v, 0, 200) for v in (snap.compressor_hz, second)]
        sample_time = _number(getattr(snap, 'sample_time', None), 0)
        if sample_time is None or sample_time > now + .5 or now - sample_time > self.SAMPLE_MAX_AGE:
            return self._pause(now, 'Brak swiezej probki temperatury')
        if self.last_sample is not None:
            if sample_time < self.last_sample:
                return self._pause(now, 'Cofniecie czasu probki; historia wyzerowana')
            if sample_time == self.last_sample:
                return self._result(now, 'obserwacja', 'Ta sama probka; bez nowej decyzji',
                                    inhibit_a03=(self.release_plan is not None or self.pending_action is not None
                                                 or self.composite_retry is not None))
            if sample_time - self.last_sample > self.HISTORY_MAX_GAP:
                self._clear_context()

        twi, two = _number(snap.twi, -10, 70), _number(snap.two, -10, 70)
        target = _number(snap.target_ch, 20, 55)
        valid_channels = [v for v in channels if v is not None]
        if None in (twi, two, target) or not valid_channels:
            return self._pause(now, 'Nieprawidlowe temperatury lub oba kanaly Hz')
        hz = max(valid_channels)
        is_running = hz > 0
        if not -5 <= two - twi <= 15:
            return self._pause(now, 'Niewiarygodna roznica Two-Twi')
        # Przy termostacie ON cala regulacja Smart jest wylacznie wodna.
        # Przy OFF / obejściu mrozu: Ti jest wolnym sygnalem komfortu.
        room_gap = room = room_target = None
        if not snap.thermostat_enabled and getattr(snap, 'room_fresh', False):
            room = _number(snap.room_temp, -10, 50)
            room_target = _number(snap.room_target, 5, 35)
            if room is not None and room_target is not None:
                room_gap = room_target - room

        event = None
        margin, return_gap = two - target, target - twi
        if self.pump_since is None:
            self.pump_since = sample_time
            event = 'obserwacja_obiegu'
        if stage != self.last_stage:
            previous_stage = self.last_stage
            self.last_stage = stage
            # Czas FLimit liczymy od wlaczenia, nie resetujemy przy zmianie
            # Quiet+FLimit 40 <-> Turbo+FLimit 45.
            if not stage[1]:
                self.flimit_since = None
            elif previous_stage is None or not previous_stage[1]:
                self.flimit_since = sample_time
            self.min_stage_since = sample_time if stage == ('quiet', True) and is_running else None
            self.candidate = self.candidate_since = self.deficit_since = None
            if self.release_plan is not None and stage != self.release_plan[1]:
                self.release_plan = None
            event = 'zmiana_zgloszonego_stanu'

        if self.running is True and not is_running:
            last_margin = self.samples[-1][4] if self.samples else margin
            self.thermal_stop = dict(time=sample_time, margin=max(margin, last_margin),
                                     candidate=max(margin, last_margin) >= 3.0)
            self.samples.clear()
            self.candidate = self.candidate_since = self.deficit_since = None
            self.pending_action = self.release_plan = self.composite_retry = None
            self.min_stage_since = None
            self.cycle_start = None
            self.warm_restart = False
            event = 'postoj_przy_zapotrzebowaniu'
        elif is_running and self.running is not True:
            self.warm_restart = bool(self.running is False and self.thermal_stop and
                                     self.thermal_stop['candidate'] and return_gap <= 2.5)
            self.cycle_start = sample_time
            self.min_stage_since = sample_time if stage == ('quiet', True) else None
            self.samples.clear()
            self.candidate = self.candidate_since = self.deficit_since = None
            event = 'cieply_restart' if self.warm_restart else 'start_sprezarki'
        self.running = is_running

        # Reject >5C discontinuities within a minute, without treating a 0.5C
        # quantisation change over 5 seconds as a spurious 6C/min sensor fault.
        jump = False
        if self.last_water is not None and sample_time - self.last_water[0] <= 60:
            jump = max(abs(twi - self.last_water[1]), abs(two - self.last_water[2])) > 5
        old = next((s for s in self.samples if sample_time - s[0] <= 60), None)
        if old is not None and sample_time - old[0] >= 45:
            jump = jump or max(abs(twi - old[1]), abs(two - old[2])) > 5
        self.last_water = (sample_time, twi, two)
        self.last_sample = sample_time
        if jump:
            self.samples.clear()
            self.candidate = self.candidate_since = self.deficit_since = None
            return self._result(now, 'nauka', 'Skok wody >5C; odbudowa trendow',
                                force=True, fresh_sample=True, cycle_event=event,
                                phase='stabilizacja_pomiaru', inhibit_a03=True)
        self.samples.append((sample_time, twi, two, target, margin))
        if room_gap is not None:
            self.room_samples.append((sample_time, room, room_target))
        else:
            self.room_samples.clear()
        while self.samples and sample_time - self.samples[0][0] > 600:
            self.samples.popleft()

        age = 0.0 if self.cycle_start is None else sample_time - self.cycle_start
        minimum_age = 0.0 if self.min_stage_since is None else sample_time - self.min_stage_since
        base = dict(fresh_sample=True, cycle_event=event, margin=round(margin, 3),
                    return_gap=round(return_gap, 3), waterdelta=round(two - twi, 3),
                    room_gap=None if room_gap is None else round(room_gap, 3),
                    compressor_age=age, min_stage_age=minimum_age,
                    compressor_running=is_running, frequency_max=hz,
                    warm_restart=self.warm_restart, target_ch=target)
        if not is_running:
            return self._result(now, 'pauza', 'Postoj sprezarki przy aktywnym obiegu i zapotrzebowaniu',
                                force=event is not None, phase='postoj_z_zapotrzebowaniem', inhibit_a03=True, **base)
        if sample_time - self.pump_since < self.PUMP_SETTLE:
            return self._result(now, 'nauka', 'Stabilizacja obiegu przez co najmniej 60 s',
                                force=event is not None, phase='stabilizacja_obiegu', **base)

        fast = self._trend(sample_time, 60, 2, 45)
        slow_in = self._trend(sample_time, 300, 1, 180)
        slow_out = self._trend(sample_time, 300, 2, 180)
        margin_fast = self._trend(sample_time, 60, 4, 45, same_target=True)
        slow_valid = slow_in is not None and slow_out is not None
        room_rows = [row for row in self.room_samples if sample_time - row[0] <= 1800]
        room_trend = (self._slope(room_rows, 1) if len(room_rows) >= 3 and
                      room_rows[-1][0] - room_rows[0][0] >= 600 else None)
        base['trend_room_30m'] = None if room_trend is None else round(room_trend, 4)
        base.update(trend_two_fast=fast, trend_two_slow=slow_out,
                    trend_twi_slow=slow_in, trend_margin=margin_fast,
                    trend_twi=slow_in, trend_two=fast)
        if fast is None:
            return self._result(now, 'nauka', 'Zbieranie co najmniej 45 s szybkiej historii Two',
                                force=event is not None, phase='obserwacja_startu', **base)
        prediction = margin + self._clamp(fast, -1.5, 1.5)
        plateau = margin >= 3.8
        approaching = (margin >= 2.2 and fast >= .30 and prediction >= 3.0)
        warm_rise = (self.warm_restart and return_gap <= 2.5 and margin >= 1.8 and
                     fast >= .25 and prediction >= 2.8)
        risk = 'high' if plateau or (margin >= 2.5 and prediction >= 4.0) else (
            'approaching' if approaching or warm_rise else 'none')
        phase = ('cieply_restart' if self.warm_restart and age < 300 else
                 'rozruch' if age < 180 else 'ograniczenie' if stage == ('quiet', True) else 'praca')
        base.update(predicted_margin=round(prediction, 3), pred_two=round(target + prediction, 3),
                    pred_twi=None if slow_in is None else round(twi + self._clamp(slow_in, -1.0, 1.0), 3),
                    risk=risk, phase=phase)
        risk_changed = self.last_risk is not None and risk != self.last_risk
        self.last_risk = risk
        force = event is not None or risk_changed

        # Wait for reported state after an accepted callback. A successful
        # callback itself must not start the stable Quiet+FL/A03 timer.
        if self.pending_action is not None:
            intent, sent_at = self.pending_action
            observed = stage == intent[1] if intent[0] == 'stage' else (
                mode == intent[1] if intent[0] == 'mode' else stage[1] == intent[1])
            if observed:
                self.pending_action = None
                force = True
                base['cycle_event'] = 'stan_po_komendzie_potwierdzony'
            elif now - sent_at < self.STATE_CONFIRM_TIMEOUT:
                return self._result(now, 'obserwacja', 'Oczekiwanie na zgloszony stan po komendzie',
                                    force=force, inhibit_a03=True, **base)
            else:
                self.pending_action = None
                return self._result(now, 'blad', 'Brak potwierdzenia stanu po komendzie',
                                    force=True, change_ack=False, inhibit_a03=True, **base)

        room_needs_heat = room_gap is None or room_gap > .15
        cooling = slow_valid and (slow_in < -.02 or slow_out < -.04 or
                                  (return_gap >= 3.5 and slow_in <= .03))
        # W trybie OFF wychlodzenie pokoju pozwala zwiekszac moc, nawet gdy
        # wolny trend wody nie jest jeszcze ujemny. Nadal wymagamy bezpiecznej
        # Two (brak ryzyka i wzrostu wody). Progi Ti sa lagodne, z histereza.
        room_boost = (room_gap is not None and room_gap >= .3 and
                      room_trend is not None and room_trend <= -.005 and
                      return_gap >= .5)
        deficit = (room_needs_heat and slow_valid and (cooling or room_boost) and
                   return_gap >= (0.5 if room_boost else 1.8) and
                   margin <= .8 and prediction <= 1.0 and fast <= .05 and risk == 'none')
        if deficit:
            if self.deficit_since is None:
                self.deficit_since = sample_time
        else:
            self.deficit_since = None
        deficit_age = 0 if self.deficit_since is None else sample_time - self.deficit_since
        ordinary_reduce = (slow_valid and return_gap <= 1.3 and slow_in >= -.03 and margin >= .5)
        comfort_reduce = (room_gap is not None and
                          (room_gap <= -.2 or
                           (room_gap <= 0 and room_trend is not None and room_trend >= .005)))
        reduce_mode = risk != 'none' or ordinary_reduce or comfort_reduce
        intent = None
        current_index = self.STAGES.index(stage)
        if reduce_mode and current_index > 0:
            intent = ('stage', self.STAGES[current_index - 1])
        elif not reduce_mode and deficit_age >= self.DEFICIT_CONFIRM and current_index < len(self.STAGES) - 1:
            # Minimalny czas FLimit dotyczy tylko jego zwalniania.
            next_stage = self.STAGES[current_index + 1]
            held = 0 if self.flimit_since is None else sample_time - self.flimit_since
            if not (stage[1] and not next_stage[1] and held < self.FLIMIT_MIN_HOLD):
                intent = ('stage', next_stage)
        # Nie uruchamiamy A03, gdy dwuelementowa zmiana nie zakonczyla sie.
        # Komenda zlozona moze przerwac sie po pierwszej bezpiecznej zmianie.
        if self.composite_retry is not None:
            wanted = self.composite_retry
            if stage == wanted:
                self.composite_retry = None
            elif stage in self.STAGES:
                # Nie dokonczamy podnoszenia mocy, jesli pojawilo sie ryzyko
                # przegrzania albo zniknal niedobor ciepla.
                increasing = self.STAGES.index(wanted) > current_index
                if increasing and (risk != 'none' or not deficit):
                    self.composite_retry = None
                else:
                    intent = ('stage', wanted)
                    reduce_mode = self.STAGES.index(wanted) < current_index

        # Keep the exit plan while A03 is restored, then perform the stage
        # change on the next eligible observation. A03 cannot reacquire in
        # the interval between those two operations.
        if self.release_plan is not None:
            planned, origin = self.release_plan
            if risk != 'none' or not deficit:
                self.release_plan = None
                self.a03_blocked_until = now + 300
            else:
                intent = planned
        inhibit = (self.release_plan is not None or self.composite_retry is not None or
                   (self.a03_blocked_until is not None and now < self.a03_blocked_until))
        allowed = (stage == ('quiet', True) and minimum_age >= 180 and slow_valid and
                   intent is None and not inhibit)
        base.update(inhibit_a03=bool(inhibit), a03_allowed=bool(allowed),
                    deficit_seconds=deficit_age)
        if intent is None:
            self.candidate = self.candidate_since = None
            reason = 'Obserwacja temperatur i marginesu; bez zmiany stopnia'
            return self._result(now, 'stabilny', reason,
                                force=force, **base)

        proposal = ('tryb=' + intent[1][0] + ', FLimit=' + ('ON' if intent[1][1] else 'OFF')
                    if intent[0] == 'stage' else
                    ('tryb=' + intent[1] if intent[0] == 'mode' else
                     'FLimit=' + ('ON' if intent[1] else 'OFF')))
        base.update(proposal=proposal, a03_allowed=False)
        if self.candidate != intent:
            self.candidate, self.candidate_since = intent, sample_time
            return self._result(now, 'potwierdzanie', 'Potwierdzanie przez co najmniej 30 s: ' + proposal,
                                force=True, **base)
        if sample_time - self.candidate_since < self.CONFIRM_SECONDS:
            return self._result(now, 'potwierdzanie', 'Oczekiwanie na kolejne swieze potwierdzenie: ' + proposal,
                                force=force, **base)
        base['inhibit_a03'] = True
        if a03_owned and ((intent[0] == 'stage' and intent[1] != ('quiet', True)) or
                          (intent[0] == 'flimit' and not intent[1]) or
                          (intent[0] == 'mode' and intent[1] != 'quiet')):
            self.release_plan = (intent, stage)
            return self._result(now, 'przywroc_a03', 'Przywroc A03 przed zmiana stopnia: ' + proposal,
                                force=True, **base)
        interval = _number(getattr(cfg, 'interval_min', None), 3, 30)
        interval = 300.0 if interval is None else interval * 60
        is_decrease = ((intent[0] == 'stage' and self.STAGES.index(intent[1]) < current_index) or
                       (intent[0] == 'flimit' and intent[1]) or
                       (intent[0] == 'mode' and self.LEVELS.index(intent[1]) < self.LEVELS.index(mode)))
        cooldown = self.RISK_ACTION_GAP if is_decrease and risk != 'none' else interval
        if self.last_action is not None and now - self.last_action < cooldown:
            return self._result(now, 'obserwacja', 'Odstep miedzy zmianami: ' + proposal,
                                force=force, **base)
        if self.last_attempt is not None and now - self.last_attempt < self.RETRY_GAP:
            return self._result(now, 'obserwacja', 'Odstep przed ponowieniem komendy: ' + proposal,
                                force=force, **base)
        self.last_attempt = now
        try:
            if intent[0] == 'stage':
                # Zmiany w parze FLimit/preset musza byc potwierdzane
                # i wykonywane w bezpiecznej kolejnosci przez adapter.
                accepted = set_stage(*intent[1]) is True if set_stage is not None else False
                if not accepted and stage[0] != intent[1][0] and stage[1] != intent[1][1]:
                    self.composite_retry = intent[1]
            else:
                accepted = (set_mode(intent[1]) if intent[0] == 'mode' else set_flimit(intent[1])) is True
        except Exception:
            LOGGER.exception('Smart Drive: callback %s nie powiodl sie', proposal)
            accepted = False
        if not accepted:
            return self._result(now, 'blad', 'Komenda odrzucona; ponowienie nie wczesniej niz za 30 s: ' + proposal,
                                force=True, change_ack=False, **base)
        self.last_action = now
        if intent[0] == 'stage':
            self.composite_retry = None
        self.pending_action = (intent, now)
        self.candidate = self.candidate_since = self.deficit_since = None
        return self._result(now, 'zmiana_trybu' if intent[0] in ('mode', 'stage') else 'zmiana_flimit',
                            'Komenda przyjeta; oczekiwanie na zgloszony stan: ' + proposal,
                            force=True, change_ack=True, command_sent=True, **base)
