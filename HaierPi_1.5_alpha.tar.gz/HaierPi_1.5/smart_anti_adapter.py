"""Verified raw-frame boundary between HaierPi and Smart Anti ON-OFF.

The serial reader only copies complete register blocks into this object.  All
decoding and control happens outside the reader thread.  ``g`` is the existing
main-module globals mapping; importing main.py from this module is unnecessary.
"""

import logging
import math
import threading
import time

from smart_anti_onoff import SmartConfig, Snapshot
from compressor_cycles import CycleObservation


LOGGER = logging.getLogger(__name__)


def _number(value, lower, upper):
    if value is None or isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if math.isfinite(number) and lower <= number <= upper else None


def _off(value):
    """Known inactive values returned by supported PyHaier flag decoders."""
    return value is False or value == 0 or str(value).strip().upper() in ('OFF', '0', '')


class SmartRuntime:
    """Cache immutable complete frames, construct snapshots, verify commands.

    Block identifiers are register counts, matching main.ReadPump:
    6 = R101, 16 = R141, 1 = R201, 22 = R241.
    GPIO readback confirms the host pin state, not physical relay contacts.
    """

    BLOCKS = (6, 16, 1, 22)
    READBACK_TIMEOUT = 15.0

    def __init__(self, g, drive, controller, *, clock=None, sleep=None, cycle_stats=None, energy_meter=None):
        self.g = g
        self.drive = drive
        self.controller = controller
        self.cycle_stats = cycle_stats
        self.energy_meter = energy_meter
        self.clock = clock or time.monotonic
        self.sleep = sleep or time.sleep
        self._frames_lock = threading.Lock()
        self._tick_lock = threading.Lock()
        self._frames = {}
        self._sequence = 0
        self.invalid_frames = 0
        self.last_snapshot = None
        self.last_error = ''
        self._frost_lock = threading.RLock()
        self._frost_active = False
        self._frost_last_good = None
        self._frost_changed = False

    def receive(self, block, frame, now=None):
        """Store a complete validated block; never call a decoder or writer."""
        stamp = self.clock() if now is None else now
        valid = (isinstance(block, int) and not isinstance(block, bool) and
                 block in self.BLOCKS and isinstance(frame, (tuple, list)) and
                 len(frame) == block and
                 all(isinstance(word, int) and not isinstance(word, bool) and
                     0 <= word <= 65535 for word in frame))
        try:
            stamp = float(stamp)
            valid = valid and math.isfinite(stamp)
        except (TypeError, ValueError, OverflowError):
            valid = False
        if not valid:
            with self._frames_lock:
                self.invalid_frames += 1
            return False
        values = tuple(frame)
        with self._frames_lock:
            previous = self._frames.get(block)
            if previous is not None and stamp < previous[0]:
                self.invalid_frames += 1
                return False
            self._sequence += 1
            self._frames[block] = (stamp, self._sequence, values)
        return True

    def _record(self, block):
        with self._frames_lock:
            return self._frames.get(block)

    def diagnostics(self):
        now = self.clock()
        with self._frames_lock:
            ages = {str(block): (now - self._frames[block][0]
                                if block in self._frames else None)
                    for block in self.BLOCKS}
            invalid = self.invalid_frames
        return {'ages_s': ages, 'invalid_frames': invalid,
                'reason': self.last_snapshot.reason if self.last_snapshot else '',
                'last_error': self.last_error}

    def _status(self, key, default=None):
        item = self.g.get('statusdict', {}).get(key, {})
        return item.get('value', default) if isinstance(item, dict) else default

    def _primary_ready(self, key):
        try:
            age = self.g['_get_primary_age'](key)
            meta = self.g.get('_temp_primary', {}).get(key, {}).get('meta_status')
            return _number(age, 0, 300) is not None and meta == 'ok'
        except Exception:
            return False

    def _pin(self, key):
        try:
            result = self.g['GPIO'].input(self.g[key])
            return bool(result) if result in (0, 1, False, True) else None
        except Exception:
            return None

    def frost_override(self):
        """Przy mrozie czasowo pomija termostat CO, bez zapisu thermostat_on.

        Histereza 2 C. Nie pozwalamy obejsc termostatu, gdy Smart/Delta,
        automatyczne sterowanie preset/FLimit lub pomiar zewnetrzny sa nieaktywne.
        Po 5 minutach braku wiarygodnego pomiaru wraca termostat (bez nowej
        komendy wymuszajacej prace ciagla). Dostep jest synchronizowany, bo
        wywoluje to zarowno petla Smart, jak i curvecalc.
        """
        cfg = self.g.get('smart_anti_config', SmartConfig())
        configured = (cfg.enabled and cfg.frost_bypass and
                      str(self.g.get('thermostat_on', '1')).strip() == '1' and
                      str(self.g.get('antionoff', '0')).strip() == '1' and
                      str(self.g.get('flimit', '')).strip().lower() == 'auto' and
                      str(self.g.get('presetautochange', '')).strip().lower() == 'auto')
        with self._frost_lock:
            if not configured:
                if self._frost_active:
                    self._frost_changed = True
                self._frost_active = False
                self._frost_last_good = None
                return False
            now = self.clock()
            value = _number(self._status('outtemp'), -60, 65)
            age = None
            try:
                age = _number(self.g['_get_primary_age']('outtemp'), 0, 120)
            except Exception:
                pass
            valid = (age is not None and value is not None and
                     self.g.get('_temp_primary', {}).get('outtemp', {}).get('meta_status') == 'ok')
            if valid:
                self._frost_last_good = now
                desired = (value < cfg.frost_temp + 2.0 if self._frost_active else
                           value <= cfg.frost_temp)
            elif self._frost_last_good is not None and now - self._frost_last_good <= 300:
                desired = self._frost_active  # brak nowych decyzji z niepewnego pomiaru
            else:
                desired = False  # bez czujnika nie wymuszamy ciaglego grzania bezterminowo
            if desired != self._frost_active:
                LOGGER.info('Smart: automatyczny termostat mrozowy %s (Tzew=%s)',
                            'POMINIETY' if desired else 'PRZYWROCONY', value if valid else 'brak')
                self._frost_active = desired
                self._frost_changed = True
            return self._frost_active

    def take_frost_transition(self):
        with self._frost_lock:
            changed = self._frost_changed
            self._frost_changed = False
            return changed

    def snapshot(self, now=None):
        """Decode one immutable frame set, with independent block ages."""
        now = self.clock() if now is None else float(now)
        with self._frames_lock:
            records = dict(self._frames)
        reasons = []
        decode_errors = set()
        decoder = self.g.get('PyHaier')

        def fresh(block, limit):
            record = records.get(block)
            return record is not None and 0 <= now - record[0] <= limit

        def decode(name, block):
            record = records.get(block)
            if record is None:
                decode_errors.add(block)
                return None
            try:
                # Some decoder versions modify their input list in place.
                return getattr(decoder, name)(list(record[2]))
            except Exception:
                decode_errors.add(block)
                return None

        target = _number(decode('GetCHTemp', 6), 20, 55)
        compensation = _number(decode('GetTempCompensation', 6), -15, 15)
        water = decode('GetTwiTwo', 16)
        twi = two = None
        if isinstance(water, (list, tuple)) and len(water) >= 2:
            twi, two = (_number(water[0], -10, 70), _number(water[1], -10, 70))
        pump = str(decode('GetPump', 16)).strip().upper()
        threeway = str(decode('Get3way', 16)).strip().upper()
        defrost = decode('GetDefrost', 16)
        antifreeze = decode('GetAntifreeze', 16)
        error = _number(decode('GetError', 16), 0, 65535)
        mode = str(decode('GetMode', 1)).strip().lower()
        frequencies = decode('GetCompInfo', 22)
        hz_first = hz_second = None
        if isinstance(frequencies, (list, tuple)) and len(frequencies) >= 2:
            hz_first = _number(frequencies[0], 0, 200)
            hz_second = _number(frequencies[1], 0, 200)

        r101 = records.get(6)
        bits = int(r101[2][0]) & 0xFF if r101 else 0
        heat_on = bool(bits & 0x01 and bits & 0x04 and not bits & 0x02)
        cool_requested = bool(bits & 0x02)
        heat_demand = self._pin('heatdemandpin')
        flimit_on = self._pin('freqlimitpin')

        special = any(str(self._status(key, 'off')).strip().lower() == 'on'
                      for key in ('antifreeze_custom', 'anti_legionella_active',
                                  'dhw_heater_assist_active'))
        special = special or bool(self.g.get('dhw_ondemand_active', False))
        try:
            special = special or bool(self.g['_service_tests_active']())
        except Exception:
            special = True

        # Restoration must also work after heat demand and the circulation pump
        # stop.  It still requires current native CO/protection/error states.
        can_restore = (fresh(6, 90) and fresh(16, 30) and
                       6 not in decode_errors and 16 not in decode_errors and
                       compensation is not None and threeway in ('CH', 'CO') and
                       _off(defrost) and _off(antifreeze) and error == 0 and
                       not cool_requested and not special)
        if not can_restore:
            reasons.append('Brak aktualnych warunkow CO / aktywna ochrona lub CWU')
        if not fresh(6, 90):
            reasons.append('Nieaktualne R101')
        if not fresh(16, 30):
            reasons.append('Nieaktualne temperatury i stan R141')
        if not fresh(1, 90):
            reasons.append('Nieaktualny tryb R201')
        if not fresh(22, 30):
            reasons.append('Nieaktualne czestotliwosci R241')
        if records.get(16) and records.get(22):
            if abs(records[16][0] - records[22][0]) > 30:
                reasons.append('Niespojne w czasie R141/R241')
        if decode_errors:
            reasons.append('Brak dekodera lub blad danych blokow: ' +
                           ','.join(str(block) for block in sorted(decode_errors)))
        if target is None or compensation is None:
            reasons.append('Brak potwierdzonej nastawy CO / kompensacji z R101')
        if twi is None or two is None:
            reasons.append('Nieprawidlowe Twi/Two')
        if hz_first is None or hz_second is None:
            reasons.append('Nieprawidlowe kanaly czestotliwosci')
        if mode not in ('quiet', 'eco', 'turbo'):
            reasons.append('Nieznany tryb Quiet/Eco/Turbo')
        if not heat_on:
            reasons.append('Grzanie CO nie jest wlaczone w R101')
        if heat_demand is not True:
            reasons.append('Brak potwierdzonego zapotrzebowania CO')
        if pump != 'ON':
            reasons.append('Pompa obiegowa nie jest wlaczona')
        if flimit_on is None:
            reasons.append('Nie mozna odczytac wyjscia FLimit')
        outside = _number(self._status('outtemp'), -60, 65)
        if not self._primary_ready('outtemp') or outside is None:
            reasons.append('Nieaktualna temperatura zewnetrzna')
        frost_active = self.frost_override()
        try:
            zone = self.g['get_temp_zone'](outside)
            # Wyjatkowo mrozowa funkcja Smart ma priorytet nad wymuszaniem
            # presetu ze strefy mrozu. Ochrony natywne Haiera bez zmian.
            if zone != 'normal' and not (zone == 'frost' and frost_active):
                reasons.append('Strefa mrozu lub ciepla')
        except Exception:
            reasons.append('Brak potwierdzenia strefy temperatury')

        thermostat_configured = str(self.g.get('thermostat_on', '1')).strip() == '1'
        thermostat = thermostat_configured and not frost_active
        room = _number(self._status('intemp'), -10, 50)
        room_target_raw = (self.g.get('direct_inside_settemp')
                           if self.g.get('heatingcurve') == 'directly'
                           else self._status('settemp'))
        room_target = _number(room_target_raw, 5, 35)
        room_fresh = self._primary_ready('intemp') and room is not None and room_target is not None
        # Brak Ti nie blokuje ochrony wody. W trybie bez termostatu Smart
        # przechodzi na wodny fallback, ale nie podnosi nowej A03.

        return Snapshot(
            ready=not reasons, reason='; '.join(reasons), can_restore=can_restore,
            compensation=compensation, target_ch=target, twi=twi, two=two,
            compressor_hz=hz_first, compressor_hz_second=hz_second,
            room_temp=room, room_target=room_target,
            thermostat_enabled=thermostat, room_fresh=room_fresh,
            frost_bypass_active=frost_active,
            classic_enabled=str(self.g.get('antionoff', '0')).strip() == '1',
            mode=mode, flimit_on=flimit_on is True,
            auto_flimit=str(self.g.get('flimit', 'auto')).strip().lower() == 'auto',
            preset_auto=str(self.g.get('presetautochange', 'auto')).strip().lower() == 'auto',
            sample_time=records[16][0] if records.get(16) else None,
            pump_on=pump == 'ON', heat_demand=heat_demand is True)

    def cycle_observation(self, now=None, wall_time=None):
        """Read-only statistics for CO and CWU, independent of Smart settings."""
        now = self.clock() if now is None else float(now)
        wall_time = time.time() if wall_time is None else float(wall_time)
        with self._frames_lock:
            records = dict(self._frames)
        errors = []
        decoder = self.g.get('PyHaier')

        def decode(name, block, required=True):
            try:
                return getattr(decoder, name)(list(records[block][2]))
            except Exception:
                if required:
                    errors.append(name)
                return None

        for block, max_age in ((6, 90), (16, 30), (22, 30)):
            if block not in records or not 0 <= now - records[block][0] <= max_age:
                errors.append('Nieaktualne dane R' + {6: '101', 16: '141', 22: '241'}[block])
        if records.get(16) and records.get(22) and abs(records[16][0] - records[22][0]) > 30:
            errors.append('Niespojne odczyty temperatur i sprezarki')
        frequencies = decode('GetCompInfo', 22)
        hz = [_number(value, 0, 200) for value in frequencies[:2]] if isinstance(
            frequencies, (list, tuple)) and len(frequencies) >= 2 else [None, None]
        if any(value is None for value in hz):
            errors.append('Brak czestotliwosci sprezarki')
        running = (True if all(value is not None and value > 0 for value in hz) else
                   False if all(value == 0 for value in hz) else None)
        valve = str(decode('Get3way', 16)).strip().upper()
        if valve not in ('CH', 'CO', 'DHW', 'CWU'):
            errors.append('Nieznany obieg CO/CWU')
        pump = str(decode('GetPump', 16)).strip().upper()
        pump_on = True if pump == 'ON' else False if pump == 'OFF' else None
        defrost, antifreeze = decode('GetDefrost', 16), decode('GetAntifreeze', 16)
        error = _number(decode('GetError', 16), 0, 65535)
        if error is None:
            errors.append('Brak stanu bledow pompy')
        bits = int(records[6][2][0]) & 0xFF if records.get(6) else 0
        power, heat, cool, tank = bool(bits & 1), bool(bits & 4), bool(bits & 2), bool(bits & 128)
        # CWU-only uses HEAT+COOL+TANK+POWER (0x87); COOL alone must not exclude CWU.
        circuit = ('cwu' if valve in ('DHW', 'CWU') and power and tank else
                   'co' if valve in ('CH', 'CO') and power and heat and not cool else 'other')
        special = not _off(defrost) or not _off(antifreeze) or error != 0
        special = special or str(self._status('antifreeze_custom', 'off')).lower() == 'on'
        try:
            special = special or bool(self.g['_service_tests_active']())
        except Exception:
            special = True
        water = decode('GetTwiTwo', 16, required=False)
        twi = two = None
        if isinstance(water, (list, tuple)) and len(water) >= 2:
            twi, two = _number(water[0], -10, 70), _number(water[1], -10, 70)
        target = _number(decode('GetCHTemp', 6, required=False), 20, 55)
        record = records.get(22)
        sample_time = record[0] if record else now
        return CycleObservation(
            timestamp=wall_time - max(0.0, now - sample_time),
            sample_id=record[1] if record else -1, sample_time=sample_time,
            running=running, circuit=circuit, heat_demand=self._pin('heatdemandpin'),
            pump_on=pump_on, twi=twi, two=two, target_ch=target,
            special=special, defrost=(not _off(defrost)) if defrost is not None else None,
            valid=not errors, reason='; '.join(errors))

    def _stage_allowed(self):
        cfg = self.g.get('smart_anti_config', SmartConfig())
        snap = self.snapshot()
        return (cfg.enabled and snap.ready and
                snap.classic_enabled and snap.auto_flimit and snap.preset_auto and
                not self.g.get('newframe'))

    def _wait_readback(self, block, decode_name, target, sequence, normalize):
        deadline = self.clock() + self.READBACK_TIMEOUT
        minimum_sequence = sequence
        queue_was_clear = False
        while self.clock() < deadline:
            record = self._record(block)
            if self.g.get('newframe'):
                queue_was_clear = False
                if record:
                    minimum_sequence = max(minimum_sequence, record[1])
            elif not queue_was_clear:
                # Require a new passive read AFTER observing an empty queue.
                # An old baseline frame cannot acknowledge a pending restore.
                minimum_sequence = max(minimum_sequence, record[1] if record else 0)
                queue_was_clear = True
            elif record and record[1] > minimum_sequence and 0 <= self.clock() - record[0] <= 30:
                try:
                    value = getattr(self.g['PyHaier'], decode_name)(list(record[2]))
                    if normalize(value) == target:
                        return True
                except Exception:
                    pass
            self.sleep(0.1)
        return False

    def _set_mode(self, mode):
        mode = str(mode).strip().lower()
        if mode not in ('quiet', 'eco', 'turbo') or not self._stage_allowed():
            return False
        record = self._record(1)
        before = record[1] if record else 0
        _message, accepted = self.g['new_presetchange'](mode)
        if accepted is not True:
            return False
        ok = self._wait_readback(1, 'GetMode', mode, before,
                                 lambda value: str(value).strip().lower())
        if not ok:
            LOGGER.warning('Smart: brak potwierdzenia trybu %s z nowego R201', mode)
        return ok

    def _set_flimit(self, on):
        if not isinstance(on, bool) or not self._stage_allowed():
            return False
        _message, status = self.g['flimitchange']('1' if on else '0')
        return status == 'success' and self._pin('freqlimitpin') is on

    def _set_stage(self, mode, flimit):
        """Przejscie dwoch nastaw bez chwilowego odblokowania Turbo 90 Hz.

        Quiet 65 -> Turbo+FLimit 45: najpierw wlacz FLimit, potem Turbo.
        Turbo+FLimit 45 -> Quiet 65: najpierw Quiet, potem zwolnij FLimit.
        Kazdy zapis jest potwierdzany oddzielnie. Nie ma gwarancji atomowosci;
        drive wstrzymuje A03 podczas niedokonczonego przejscia.
        """
        mode = str(mode).strip().lower()
        if mode not in ('quiet', 'eco', 'turbo') or not isinstance(flimit, bool):
            return False
        if not self._stage_allowed():
            return False
        snap = self.snapshot()
        if (snap.mode, snap.flimit_on) == (mode, flimit):
            return True
        # Najpierw ograniczamy maksymalna moc, potem podnosimy preset.
        if flimit and not snap.flimit_on:
            if not self._set_flimit(True):
                return False
        # Przy zwalnianiu FLimit najpierw zmniejszamy preset.
        if snap.mode != mode and not self._set_mode(mode):
            return False
        if not flimit and snap.flimit_on:
            if not self._set_flimit(False):
                return False
        return True

    def _set_a03(self, value):
        value = _number(value, -15, 15)
        if value is None or abs(value * 2 - round(value * 2)) > 1e-6 or self.g.get('newframe'):
            return False
        snap = self.snapshot()
        if not snap.can_restore:
            return False
        owned = self.controller.owned or {}
        restoring = value == owned.get('baseline')
        cfg = self.g.get('smart_anti_config', SmartConfig())
        if not restoring and not (cfg.enabled and cfg.a03_live and snap.ready and
                                  value <= cfg.max_compensation):
            return False
        record = self._record(6)
        before = record[1] if record else 0
        _message, accepted = self.g['new_tempcompchange'](value, source='smart')
        if accepted is not True:
            return False
        ok = self._wait_readback(6, 'GetTempCompensation', value, before,
                                 lambda current: _number(current, -15, 15))
        if not ok:
            LOGGER.warning('Smart: brak potwierdzenia A03=%s z nowego R101', value)
        return ok

    def _publish(self, drive, result):
        publish = self.g.get('ischanged')
        if publish is None:
            return
        values = {
            'smart_anti_status': result.get('status', 'blad'),
            'smart_anti_reason': ('Tryb: ' + drive.get('status', 'blad') + ' (' +
                                  drive.get('reason', '') + '); A03: ' + result.get('reason', '')),
            'smart_anti_target': result.get('target', 'N.A.'),
            'smart_anti_baseline': result.get('base', 'N.A.'),
        }
        for key, value in values.items():
            try:
                publish(key, value)
            except Exception:
                LOGGER.exception('Smart: nie mozna opublikowac %s', key)

    def _energy_observe(self):
        """Separate read-only energy sample from current Modbus frames."""
        now_m = self.clock()
        with self._frames_lock:
            frames = dict(self._frames)
        valid = all(k in frames and 0 <= now_m - frames[k][0] <= (90 if k == 6 else 30)
                    for k in (6, 16, 22))
        if valid and abs(frames[16][0] - frames[22][0]) > 30:
            valid = False
        decoder = self.g.get('PyHaier')
        try:
            data = decoder.GetCompInfo(list(frames[22][2])) if valid else None
            pump = str(decoder.GetPump(list(frames[16][2]))).upper() if valid else ''
            valve = str(decoder.Get3way(list(frames[16][2]))).upper() if valid else ''
            heater = str(decoder.GetHeater(list(frames[16][2]))).upper() if valid else ''
            defrost = str(decoder.GetDefrost(list(frames[16][2]))).upper() if valid else ''
            tao = decoder.GetTao(list(frames[22][2])) if valid else None
            hz = _number(data[0], 0, 200) if valid and len(data) > 2 else None
            current = _number(data[2], 0, 60) if valid and len(data) > 2 else None
            running = (hz > 0) if hz is not None else None
            valid = (valid and hz is not None and current is not None and
                     pump in ('ON', 'OFF') and heater in ('ON', 'OFF') and
                     valve in ('CH', 'CO', 'DHW', 'CWU'))
        except Exception:
            valid = False
            hz = current = tao = None
            running = None
            pump = heater = valve = defrost = ''
        options = {k: self.g['config'].get('ENERGY', k, fallback='')
                   for k in self.g['energy_defaults']}
        self.energy_meter.observe(
            ts=time.time(), running=running, hz=hz, current_a=current,
            pump=(pump == 'ON') if valid else None,
            heater=(heater == 'ON') if valid else None,
            defrost=(defrost == 'DEFROST'), outside_c=tao,
            circuit='cwu' if valve in ('DHW', 'CWU') else 'co' if valve in ('CH', 'CO') else 'other',
            valid=valid, options=options)

    def tick(self):
        """Run once; overlapping scheduler calls never issue duplicate writes."""
        if not self._tick_lock.acquire(blocking=False):
            return None
        try:
            if self.cycle_stats is not None:
                try:
                    self.cycle_stats.observe(self.cycle_observation())
                except Exception:
                    LOGGER.exception('Liczniki cykli: blad obserwacji; sterowanie pozostaje niezalezne')
            if self.energy_meter is not None:
                try:
                    self._energy_observe()
                except Exception:
                    LOGGER.exception('Energia: blad obserwacji (sterowanie bez zmian)')
            cfg = self.g.get('smart_anti_config', SmartConfig())
            snap = self.snapshot()
            self.last_snapshot = snap
            drive, result = self.controller.coordinate(
                self.drive, cfg, snap, self._set_mode, self._set_flimit, self._set_a03,
                now=self.clock(), set_stage=self._set_stage)
            self.last_error = ''
            self._publish(drive, result)
            return drive, result
        except Exception as exc:
            self.last_error = str(exc)
            LOGGER.exception('Smart: blad adaptera, dalsze sterowanie w tej iteracji wstrzymane')
            drive = {'status': 'pauza', 'reason': 'Blad adaptera odczytow/sterowania'}
            result = {'status': 'blad', 'reason': 'Blad adaptera; sprawdz log systemowy'}
            self._publish(drive, result)
            return drive, result
        finally:
            self._tick_lock.release()
