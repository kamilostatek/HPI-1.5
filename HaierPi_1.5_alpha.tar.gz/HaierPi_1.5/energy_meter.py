"""HaierPi energy estimation / HA meter input. Read-only monitoring, no pump commands.

Estimated values are exploratory; external cumulative kWh is authoritative when
selected. The two sources are never added or silently mixed.
"""
import datetime
import json
import logging
import math
import os
import re
import tempfile
import threading
import time
from collections import defaultdict

DEFAULTS = {'pump_w': 30.0, 'heater_w': 0.0, 'standby_w': 7.0,
            'crankcase_w': 25.0, 'crank_on_c': 8.0, 'crank_off_c': 9.0,
            'mode': 'estimate', 'ha_entity': '', 'price_kwh': 0.0}
POWER_FIELDS = ('pump_w', 'heater_w', 'standby_w', 'crankcase_w')
NUM_FIELDS = POWER_FIELDS + ('crank_on_c', 'crank_off_c', 'price_kwh')
ENTITY_RE = re.compile(r'^sensor\.[a-z0-9_]{1,180}$')


def valid_options(values):
    result = dict(DEFAULTS)
    for key in DEFAULTS:
        raw = str(values.get(key, '')).strip().replace(',', '.')
        if not raw:
            continue
        if key in NUM_FIELDS:
            try:
                n = float(raw)
            except ValueError:
                raise ValueError('Niepoprawna wartosc: ' + key)
            lo, hi = (-35, 45) if key.endswith('_c') else ((0, 100) if key == 'price_kwh' else (0, 30000))
            if not math.isfinite(n) or n < lo or n > hi:
                raise ValueError('Niepoprawny zakres: ' + key)
            result[key] = n
        else:
            result[key] = raw
    if result['crank_off_c'] <= result['crank_on_c']:
        raise ValueError('Prog wylaczenia karteru musi byc wyzszy od progu wlaczenia')
    if result['mode'] not in ('estimate', 'ha'):
        raise ValueError('Nieznane zrodlo energii')
    if result['ha_entity'] and not ENTITY_RE.fullmatch(result['ha_entity']):
        raise ValueError('Encja musi miec format sensor.nazwa')
    if result['mode'] == 'ha' and not result['ha_entity']:
        raise ValueError('Wybierz encje licznika kWh z HA')
    return result


def _finite(raw, lo=-1e9, hi=1e9):
    try:
        n = float(raw)
        return n if math.isfinite(n) and lo <= n <= hi else None
    except (TypeError, ValueError, OverflowError):
        return None


def _day(ts):
    return datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')


class EnergyMeter:
    """30-day bounded daily ledger, checkpointed in /opt/haier/logs."""

    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()
        self.days = {}
        self.current = {}
        self.last_observation = None
        self.last_save = 0
        self.ha_last_value = None
        self.ha_last_ts = None
        self.ha_last_received = None
        self.ha_error = 'Brak odczytu licznika'
        self.ha_identity = None
        self.previous_crank = False
        self._load()

    def _load(self):
        try:
            if not os.path.exists(self.path):
                return
            if os.path.islink(self.path) or os.stat(self.path).st_size > 1024 * 1024:
                raise ValueError('Nieprawidlowy plik historii energii')
            with open(self.path, encoding='utf-8') as stream:
                data = json.load(stream)
            if data.get('version') != 1 or not isinstance(data.get('days'), dict):
                raise ValueError('Nieznany format historii')
            for key, value in data['days'].items():
                if re.fullmatch(r'\d{4}-\d{2}-\d{2}', key) and isinstance(value, dict):
                    self.days[key] = {field: max(0, float(value.get(field, 0)))
                                      for field in ('estimate', 'ha', 'co', 'cwu', 'other')}
            # HA reference intentionally not restored: a fresh HA sample must set baseline.
        except Exception:
            logging.exception('Energia: blad odczytu historii, nie nadpisuje uszkodzonego pliku')
            self._read_error = True
        else:
            self._read_error = False

    def _add(self, ts, field, kwh, circuit=None):
        if kwh <= 0 or not math.isfinite(kwh):
            return
        date = _day(ts)
        d = self.days.setdefault(date, dict.fromkeys(('estimate', 'ha', 'co', 'cwu', 'other'), 0.0))
        d[field] += kwh
        if field == 'estimate':
            d[circuit if circuit in ('co', 'cwu') else 'other'] += kwh

    def _checkpoint(self, now):
        if getattr(self, '_read_error', False) or now - self.last_save < 300:
            return
        self.last_save = now
        cutoff = (datetime.datetime.fromtimestamp(now) - datetime.timedelta(days=30)).strftime('%Y-%m-%d')
        self.days = {k: v for k, v in self.days.items() if k >= cutoff}
        directory = os.path.dirname(self.path)
        tmp = None
        try:
            os.makedirs(directory, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=directory, prefix='.energy-')
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                os.fchmod(stream.fileno(), 0o600)
                json.dump({'version': 1, 'days': self.days}, stream, separators=(',', ':'))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(tmp, self.path)
        except OSError:
            logging.exception('Energia: blad zapisu historii')
        finally:
            if tmp and os.path.exists(tmp):
                os.unlink(tmp)

    def observe(self, *, ts, running, hz, current_a, pump, heater, defrost,
                outside_c, circuit, valid, options):
        """Observe coherent raw-frame snapshots. Missing frames never accrue energy."""
        with self.lock:
            if not valid or not isinstance(running, bool) or not isinstance(pump, bool):
                self.last_observation = None
                self.last_watts = None
                self.current = {'status': 'Nieaktualne dane pompy'}
                return
            if self.last_observation is not None and not 0 < ts - self.last_observation < 45:
                self.last_observation = None
            opts = valid_options(options)
            temp = _finite(outside_c, -50, 65)
            if temp is not None:
                if temp < opts['crank_on_c']:
                    self.previous_crank = True
                elif temp >= opts['crank_off_c']:
                    self.previous_crank = False
            # Crank heater state during compressor operation is not electrically verified;
            # compressor model is fitted to the whole L1, do not add crankcase twice.
            crank = self.previous_crank
            if running:
                amperes = _finite(current_a, 0, 60)
                freq = _finite(hz, 0, 150)
                watts = (32.93 + 5.89 * amperes * freq + (opts['heater_w'] if heater else 0)) if amperes is not None and freq is not None and freq > 0 else None
            else:
                watts = opts['standby_w'] + (opts['pump_w'] if pump else 0) + (opts['crankcase_w'] if crank else 0) + (opts['heater_w'] if heater else 0)
            if watts is None or watts < 0 or watts > 30000:
                self.last_observation = None
                self.last_watts = None
                self.current = {'status': 'Brak wiarygodnej mocy'}
                return
            prev = self.last_observation
            if prev is not None:
                # Trapezoidal mean. Uses previous circuit for bucket; gaps => no accrual.
                dt = ts - prev
                self._add(ts, 'estimate', (self.last_watts + watts) * .5 * dt / 3600000.0, circuit)
            self.last_observation = ts
            self.last_watts = watts
            self.current = dict(status='Szacowanie', watts=round(watts, 1),
                                running=running, pump=pump, heater=heater,
                                crankcase=crank, defrost=defrost, circuit=circuit,
                                updated=ts)
            self._checkpoint(ts)

    def external(self, *, entity, value, unit, ts, received, device_id):
        """Receive HA monotonically increasing total kWh; no delta on first sample."""
        with self.lock:
            if unit not in ('kWh', 'Wh'):
                self.ha_error = 'Encja musi miec jednostke kWh albo Wh'
                return
            number = _finite(value, 0, 1e12)
            if number is None:
                self.ha_error = 'HA nie zwrocil liczby'
                return
            number /= 1000 if unit == 'Wh' else 1
            if device_id != self.ha_identity:
                self.ha_identity = device_id
                self.ha_last_value = None
                self.ha_last_ts = None
            if (self.ha_last_value is not None and self.ha_last_ts is not None and
                    ts > self.ha_last_ts and ts - self.ha_last_ts <= 3600):
                delta = number - self.ha_last_value
                # Meter reset / extreme jump => establish new baseline, never invent kWh.
                if 0 <= delta <= (ts-self.ha_last_ts) / 3600.0 * 30:
                    self._add(ts, 'ha', delta)
            self.ha_last_value = number
            self.ha_last_ts = ts
            self.ha_last_received = received
            self.ha_error = ''
            self._checkpoint(received)

    def set_ha_error(self, msg):
        with self.lock:
            self.ha_error = msg[:180]

    def summary(self, options):
        with self.lock:
            opts = valid_options(options)
            selected = 'ha' if opts['mode'] == 'ha' else 'estimate'
            now = time.time()
            today = _day(now)
            totals = {period: 0.0 for period in ('today', '7d', '30d')}
            for day, values in self.days.items():
                age = (datetime.date.fromtimestamp(now) - datetime.date.fromisoformat(day)).days
                if age == 0: totals['today'] += values[selected]
                if 0 <= age < 7: totals['7d'] += values[selected]
                if 0 <= age < 30: totals['30d'] += values[selected]
            fresh = self.ha_last_received is not None and now - self.ha_last_received <= 180
            status = ('Odczyt HA aktualny' if fresh else 'Brak aktualnego odczytu z HA') if selected == 'ha' else self.current.get('status', 'Czekam na dane')
            price = opts['price_kwh']
            costs = {period: round(energy * price, 2) for period, energy in totals.items()} if price > 0 else None
            return dict(source=selected, status=status, ha_error=self.ha_error if selected == 'ha' else '',
                        ha_fresh=fresh, current_w=self.current.get('watts') if selected == 'estimate' else None,
                        total_kwh={k: round(v, 4) for k, v in totals.items()}, cost_pln=costs, price_kwh=price,
                        estimate_breakdown={k: round(self.days.get(today, {}).get(k, 0), 4) for k in ('co', 'cwu', 'other')},
                        last_sample=self.ha_last_received if selected == 'ha' else self.current.get('updated'),
                        estimated=True if selected == 'estimate' else False)
