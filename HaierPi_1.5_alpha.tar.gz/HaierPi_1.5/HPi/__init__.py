# HaierPi GPIO compatibility namespace.
