"""HaierPi 1.5: adaptacyjny Smart Anti ON-OFF (Twi/Two -> tryb/FLimit -> A03).

Oryginalny progowy Anti ON-OFF Delta pozostaje nietkniety i jest uzywany,
gdy Smart jest wylaczony. Smart na zywo
analizuje szybki trend Two, wolniejsze trendy Twi/Two i ponowne starty po taktowaniu,
sterujac Turbo/Eco/Quiet oraz automatycznym FLimit. A03 jest opcjonalnym
ostatnim etapem dopiero przy stabilnym Quiet+FLimit. Nie sterujemy
bezposrednio sprezarka ani fabrycznymi zabezpieczeniami Haiera.

A03 nie jest bezposrednio progiem stop. Smart i zgoda na zmiane A03 sa
domyslnie wylaczone. Po wlaczeniu Smart steruje trybem i FLimit;
kompensacje zmienia tylko po wlaczeniu osobnej opcji A03.
"""

from collections import deque
from dataclasses import dataclass
from datetime import date, datetime, timedelta
import json
import logging
import math
import os
import re
from pathlib import Path
import tempfile
import threading
import time

from smart_anti_drive import SmartAdaptiveDrive

LOGGER = logging.getLogger(__name__)


def _number(value, lo=None, hi=None):
    try:
        number = float(str(value).strip().replace(',', '.'))
    except (TypeError, ValueError, OverflowError):
        return None
    if not math.isfinite(number):
        return None
    if lo is not None and number < lo:
        return None
    if hi is not None and number > hi:
        return None
    return number


def _step(value):
    """Kompensacja A03 obsluguje dokladnie polstopnie C."""
    return round(float(value) * 2) / 2


@dataclass(frozen=True)
class SmartConfig:
    enabled: bool = False
    interval_min: float = 5.0  # minimalny odstep zwyklych zmian; redukcje pilne moga byc szybsze
    max_compensation: float = 1.0  # bezwzgledny gorny limit A03 ustawianej przez Smart
    a03_live: bool = False  # zgoda na automatyczne zmiany kompensacji temperatury
    frost_bypass: bool = False  # tylko Smart, automatyczne pomijanie termostatu w mrozie
    frost_temp: float = -10.0  # prog wejscia; wyjscie = prog + 2 C

    @staticmethod
    def obsolete_keys():
        """Rozpoznawane tylko przy migracji; nie sa aktywnymi ustawieniami."""
        return ('smart_anti_onoff_dry_run', 'smart_anti_onoff_max_offset',
                'smart_anti_onoff_quiet_limit_hz', 'smart_anti_onoff_eco_limit_hz',
                'smart_anti_onoff_turbo_limit_hz', 'smart_anti_onoff_flimit_limit_hz')

    def as_settings(self):
        return {
            'smart_anti_onoff': '1' if self.enabled else '0',
            'smart_anti_onoff_a03_live': '1' if self.a03_live else '0',
            'smart_anti_onoff_interval_min': f'{self.interval_min:g}',
            'smart_anti_onoff_max_compensation': f'{self.max_compensation:.1f}',
            'smart_anti_onoff_frost_bypass': '1' if self.frost_bypass else '0',
            'smart_anti_onoff_frost_temp': f'{self.frost_temp:.1f}',
        }

    def apply_to(self, settings):
        for key in self.obsolete_keys():
            settings.pop(key, None)
        settings.update(self.as_settings())

    @classmethod
    def from_settings(cls, settings):
        def flag(key, default):
            value = str(settings.get(key, default)).strip()
            if value not in ('0', '1'):
                raise ValueError(f'{key}: musi wynosic 0 lub 1')
            return value == '1'

        interval = _number(settings.get('smart_anti_onoff_interval_min', '5'), 3, 30)
        if interval is None or (interval * 2) % 1 != 0:
            raise ValueError('smart_anti_onoff_interval_min: wymagane 3..30, krok 0.5')
        new_key = 'smart_anti_onoff_max_compensation'
        legacy = new_key not in settings
        if legacy:
            previous = _number(settings.get('smart_anti_onoff_max_offset'), 0.5, 3.0)
            maximum = previous if previous is not None and (previous * 2) % 1 == 0 else 1.0
        else:
            maximum = _number(settings[new_key], -15, 15)
            if maximum is None or (maximum * 2) % 1 != 0:
                raise ValueError(new_key + ': wymagane -15..15 C, krok 0.5')
        frost_temp = _number(settings.get('smart_anti_onoff_frost_temp', '-10'), -25, 5)
        if frost_temp is None or abs(frost_temp * 2 - round(frost_temp * 2)) > 1e-6:
            raise ValueError('smart_anti_onoff_frost_temp: wymagane -25..5 C, krok 0.5')
        enabled = flag('smart_anti_onoff', '0')
        # Dawnej symulacji nie zamieniamy w aktywne sterowanie przy aktualizacji.
        # Nowy formularz zapisuje nowy klucz i usuwa stare opcje jednorazowo.
        old_simulation = settings.get('smart_anti_onoff_dry_run')
        if ((old_simulation is not None and str(old_simulation).strip() != '0') or
                (legacy and old_simulation is None)):
            enabled = False
        return cls(
            enabled=enabled,
            interval_min=interval,
            max_compensation=maximum,
            a03_live=flag('smart_anti_onoff_a03_live', '0'),
            frost_bypass=flag('smart_anti_onoff_frost_bypass', '0'),
            frost_temp=frost_temp,
        )


@dataclass(frozen=True)
class Snapshot:
    """Tylko aktualne, zweryfikowane odczyty; gotowosc bada integracja w main.py."""
    ready: bool
    reason: str
    can_restore: bool = False
    compensation: object = None
    target_ch: object = None
    twi: object = None
    two: object = None
    compressor_hz: object = None
    room_temp: object = None
    room_target: object = None
    # Gdy termostat ON, Smart nie wykorzystuje Ti. Przy OFF pomiar jest opcjonalny
    # dla sterowania woda, ale wymagany do regulacji komfortu i nowych zmian A03.
    thermostat_enabled: bool = False  # efektywny termostat (po obejściu mrozu)
    room_fresh: bool = False
    frost_bypass_active: bool = False
    classic_enabled: bool = False
    mode: str = ''
    flimit_on: bool = False
    auto_flimit: bool = True
    preset_auto: bool = True
    sample_time: object = None  # monotoniczny czas pelnej ramki wody
    compressor_hz_second: object = None
    pump_on: object = None
    heat_demand: object = None


class SmartEventHistory:
    """Daily log on persistent SD, with 30-day retention and hard size caps.

    Log path is deliberately under /opt, because /var/log on DietPi can be a
    RAM-based filesystem and may not survive restart. One normal and one
    rotated file per day, both capped at 256 KiB (max about 15 MiB total).
    Only a decision, a change of state or a 30-minute heartbeat is recorded;
    the high-frequency main loop never generates one line per iteration.
    """

    NAME_RE = re.compile(r'^smart_anti_(\d{4}-\d{2}-\d{2})\.log(\.1)?$')

    def __init__(self, directory, retention_days=30, max_file_bytes=256 * 1024):
        if not 1 <= retention_days <= 365 or max_file_bytes < 256:
            raise ValueError('invalid history limits')
        self.directory = Path(directory)
        self.retention_days = retention_days
        self.max_file_bytes = max_file_bytes
        self._last_cleanup_date = None
        self._last_status = None
        self._last_reason = None
        self._last_mode = None
        self._last_stage = None
        self._last_record_time = None
        self._last_error_date = None
        self._last_drive_time = None
        self._last_drive_signature = None
        self._lock = threading.Lock()

    @staticmethod
    def _as_number(value):
        number = _number(value)
        return None if number is None else round(number, 2)

    @staticmethod
    def _format_number(value):
        number = _number(value)
        return '-' if number is None else f'{number:.1f}'

    @staticmethod
    def _format_trend(value):
        number = _number(value)
        return '-' if number is None else f'{number:+.3f}'

    @staticmethod
    def _clean(text):
        return re.sub(r'[\r\n\t|]+', ' ', str(text or '')).strip()[:480]

    def _cleanup(self, today):
        if not self.directory.is_dir():
            return
        cutoff = today - timedelta(days=self.retention_days - 1)
        for item in self.directory.iterdir():
            matched = self.NAME_RE.fullmatch(item.name)
            if matched is None or not item.is_file() or item.is_symlink():
                continue
            try:
                file_day = date.fromisoformat(matched.group(1))
            except ValueError:
                continue
            if file_day < cutoff:
                item.unlink()

    def _append(self, today, line):
        self.directory.mkdir(mode=0o750, parents=True, exist_ok=True)
        path = self.directory / f'smart_anti_{today.isoformat()}.log'
        backup = path.with_name(path.name + '.1')
        encoded = (line + '\n').encode('utf-8')
        if len(encoded) > self.max_file_bytes:
            raise OSError('Smart history event exceeds per-file limit')
        if path.exists():
            if not path.is_file() or path.is_symlink():
                raise OSError('Unexpected log file type')
            if path.stat().st_size + len(encoded) > self.max_file_bytes:
                if backup.exists() or backup.is_symlink():
                    backup.unlink()
                os.replace(path, backup)
        fd = os.open(str(path), os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0), 0o640)
        with os.fdopen(fd, 'ab') as logfile:
            logfile.write(encoded)

    def _line(self, cfg, snap, result, when, trend):
        mode = 'AUTOMAT' if cfg.enabled else 'WYLACZONY'
        curr = self._format_number(result.get('current', snap.compensation))
        target = self._format_number(result.get('target'))
        base = self._format_number(result.get('base'))
        temp_delta = None
        if _number(snap.two) is not None and _number(snap.twi) is not None:
            temp_delta = float(snap.two) - float(snap.twi)
        fields = [
            when.isoformat(timespec='seconds'), mode,
            str(result.get('status', '')).upper(),
            'A03=' + curr + ('->' + target if target != '-' else ''),
            'baza=' + base,
            'Twi=' + self._format_number(snap.twi),
            'Two=' + self._format_number(snap.two),
            'dT=' + self._format_number(temp_delta),
            'Tzad_CO=' + self._format_number(snap.target_ch),
            'Hz_1=' + self._format_number(snap.compressor_hz),
            'Hz_2=' + self._format_number(snap.compressor_hz_second),
            'tryb=' + self._clean(snap.mode),
            'FLimit=' + ('ON' if snap.flimit_on else 'OFF'),
            'Delta=' + self._format_number((float(snap.target_ch) - float(snap.twi)) if _number(snap.target_ch) is not None and _number(snap.twi) is not None else None),
            'pokoj=' + self._format_number(snap.room_temp),
            'pokoj_zad=' + self._format_number(snap.room_target),
            'trend_Twi=' + self._format_trend(trend),
            'powod=' + self._clean(result.get('reason')),
        ]
        return ' | '.join(fields)

    def record(self, cfg, snap, result, evaluated=False, now_monotonic=None,
               when=None, trend=None):
        """Best-effort event logging: logging failure never causes Modbus writes."""
        when = when or datetime.now().astimezone()
        if when.tzinfo is None:
            when = when.astimezone()
        now_monotonic = time.monotonic() if now_monotonic is None else float(now_monotonic)
        with self._lock:
            today = when.date()
            if today != self._last_cleanup_date:
                try:
                    self._cleanup(today)
                    self._last_cleanup_date = today
                except OSError:
                    if self._last_error_date != today:
                        LOGGER.exception('Smart Anti On-Off: cannot expire old history')
                        self._last_error_date = today
            status = str(result.get('status', ''))
            reason = str(result.get('reason', ''))
            mode = bool(cfg.enabled)
            stage = (bool(snap.classic_enabled), str(snap.mode).strip().lower(), bool(snap.flimit_on))
            changed = status != self._last_status or mode != self._last_mode or stage != self._last_stage
            if status in ('pauza', 'przywracanie', 'wstrzymany', 'blad') and reason != self._last_reason:
                changed = True
            heartbeat = (cfg.enabled and self._last_record_time is not None and
                         now_monotonic - self._last_record_time >= 1800)
            should_log = changed or evaluated or heartbeat
            if not should_log:
                return False
            # Throttle rapidly flapping status/reason transitions but never
            # suppress a real A03 action or restoration.
            critical = status in ('korekta', 'przywrocony', 'zwolniony')
            if (changed and not critical and not evaluated and
                    self._last_record_time is not None and
                    0 <= now_monotonic - self._last_record_time < 60):
                return False
            try:
                self._append(today, self._line(cfg, snap, result, when, trend))
            except (OSError, ValueError):
                if self._last_error_date != today:
                    LOGGER.exception('Smart Anti On-Off: cannot write SD history')
                    self._last_error_date = today
                return False
            self._last_status, self._last_reason, self._last_mode = status, reason, mode
            self._last_stage = stage
            self._last_record_time = now_monotonic
            return True

    def record_stage(self, cfg, snap, result, now_monotonic=None, when=None):
        """Zmiany natychmiast, powtarzany stan co 5 min; limit zuzycia karty."""
        if not cfg.enabled or not snap.classic_enabled:
            return False
        if not result.get('evaluated') and not result.get('cycle_event') and result.get('status') not in (
                'zmiana_trybu', 'zmiana_flimit',
                'blad', 'przywroc_a03'):
            return False
        when = when or datetime.now().astimezone()
        if when.tzinfo is None:
            when = when.astimezone()
        now_monotonic = time.monotonic() if now_monotonic is None else float(now_monotonic)
        fields = [
            when.isoformat(timespec='seconds'),
            'SMART_DRIVE',
            'AUTOMAT',
            self._clean(result.get('status')),
            'Twi=' + self._format_number(snap.twi),
            'Two=' + self._format_number(snap.two),
            'dT=' + self._format_number(_number(snap.two) - _number(snap.twi)
                    if _number(snap.two) is not None and _number(snap.twi) is not None else None),
            'Tzad_CO=' + self._format_number(snap.target_ch),
            'Two_minus_zadana=' + self._format_number(result.get('margin')),
            'zadana_minus_Twi=' + self._format_number(result.get('return_gap')),
            'trend_Two_60s=' + self._format_trend(result.get('trend_two_fast')),
            'trend_Two_300s=' + self._format_trend(result.get('trend_two_slow')),
            'trend_Twi_300s=' + self._format_trend(result.get('trend_twi_slow')),
            'prognoza_nadwyzki=' + self._format_number(result.get('predicted_margin')),
            'ryzyko=' + self._clean(result.get('risk')),
            'faza=' + self._clean('Ponowny start po taktowaniu' if result.get('phase') == 'cieply_restart'
                                   else result.get('phase')),
            'cykl=' + self._clean('Ponowny start po taktowaniu' if result.get('cycle_event') == 'cieply_restart'
                                   else result.get('cycle_event')),
            'pompa=' + str(snap.pump_on),
            'zapotrzebowanie=' + str(snap.heat_demand),
            'Hz_1=' + self._format_number(snap.compressor_hz),
            'Hz_2=' + self._format_number(snap.compressor_hz_second),
            'tryb=' + self._clean(snap.mode),
            'FLimit=' + ('ON' if snap.flimit_on else 'OFF'),
            'propozycja=' + self._clean(result.get('proposal')),
            'potwierdzenie_komendy=' + ('TAK' if result.get('change_ack') is True else
                                       'NIE' if result.get('change_ack') is False else '-'),
            'powod=' + self._clean(result.get('reason')),
        ]
        with self._lock:
            signature = (result.get('status'), result.get('phase'), result.get('risk'))
            action = result.get('status') in (
                'zmiana_trybu', 'zmiana_flimit',
                'blad', 'przywroc_a03')
            if (not action and not result.get('cycle_event') and
                    signature == self._last_drive_signature and self._last_drive_time is not None
                    and 0 <= now_monotonic - self._last_drive_time < 300):
                return False
            try:
                if self._last_cleanup_date != when.date():
                    self._cleanup(when.date())
                    self._last_cleanup_date = when.date()
                self._append(when.date(), ' | '.join(fields))
                self._last_drive_time, self._last_drive_signature = now_monotonic, signature
            except (OSError, ValueError):
                if self._last_error_date != when.date():
                    LOGGER.exception('Smart drive: cannot write SD history')
                    self._last_error_date = when.date()
                return False
        return True

    def tail(self, limit=80):
        """Newest first, at most 200 lines; only hardcoded log names are read."""
        limit = max(1, min(200, int(limit)))
        with self._lock:
            if not self.directory.is_dir():
                return []
            candidates = []
            cutoff = date.today() - timedelta(days=self.retention_days - 1)
            for item in self.directory.iterdir():
                match = self.NAME_RE.fullmatch(item.name)
                if match is None or not item.is_file() or item.is_symlink():
                    continue
                try:
                    day = date.fromisoformat(match.group(1))
                except ValueError:
                    continue
                if day >= cutoff:
                    # Current .log is newer than .log.1 from the same day.
                    candidates.append((day, 1 if match.group(2) is None else 0, item))
            candidates.sort(reverse=True)
            lines = []
            for _, _, path in candidates:
                try:
                    with path.open('r', encoding='utf-8', errors='replace') as logfile:
                        lines.extend(reversed(list(deque(logfile, maxlen=limit))))
                except OSError:
                    continue
                if len(lines) >= limit:
                    break
            return [entry.rstrip('\r\n') for entry in lines[:limit]]


class SmartAntiOnOff:
    """Ostatni, opcjonalny etap A03; kierunek A03 wymaga weryfikacji na pompie.

    Zapis bazowej nastawy następuje dopiero przed pierwszą rzeczywistą
    korektą. Nierozstrzygnięta komenda pozostaje w dzienniku transakcji;
    stary odczyt nie jest dowodem odrzucenia komendy. Nie wyznaczamy
    fabrycznego progu stop jako Tzad+A03.
    """

    def __init__(self, state_path, history_dir=None):
        self.path = Path(state_path)
        self.history = SmartEventHistory(history_dir) if history_dir else None
        self.lock = threading.Lock()
        self.owned = None
        self.state_error = None
        self.last_eval = None
        self.last_change = None
        self.last_attempt = None
        self.last_sample = None
        self.last_clock = None
        self.candidate = 0
        self.candidate_since = None
        self.candidate_count = 0
        self._load_state()

    @staticmethod
    def _a03(value):
        value = _number(value, -15, 15)
        if value is None or abs(value * 2 - round(value * 2)) > 1e-6:
            return None
        return _step(value)

    @staticmethod
    def _result(status, reason='', **values):
        return dict(status=status, reason=reason, **values)

    def _load_state(self):
        try:
            if not self.path.exists():
                return
            with self.path.open('r', encoding='utf-8') as stream:
                raw = json.load(stream)
            baseline, expected = self._a03(raw.get('baseline')), self._a03(raw.get('expected'))
            pending = self._a03(raw.get('pending')) if raw.get('pending') is not None else None
            if baseline is None or expected is None or (raw.get('pending') is not None and pending is None):
                raise ValueError('Nieprawidlowy zapis A03')
            self.owned = dict(baseline=baseline, expected=expected, pending=pending,
                              suspended=bool(raw.get('suspended', False)))
            if raw.get('pending_previous') is not None:
                previous = self._a03(raw['pending_previous'])
                if previous is None or pending is None:
                    raise ValueError('Nieprawidlowy poprzedni zapis oczekujacy A03')
                self.owned['pending_previous'] = previous
        except Exception as exc:
            self.state_error = str(exc)
            LOGGER.exception('Smart: unreadable A03 journal; writes blocked')

    def _sync_directory(self):
        descriptor = os.open(str(self.path.parent), os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def _persist(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary = tempfile.mkstemp(prefix='.smart-aoo-', dir=str(self.path.parent))
        try:
            with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
                os.fchmod(stream.fileno(), 0o600)
                json.dump(self.owned, stream, sort_keys=True)
                stream.write('\n')
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            self._sync_directory()
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def _release(self):
        if self.path.exists():
            self.path.unlink()
            self._sync_directory()
        self.owned = None
        self._reset_observation()

    def _reset_observation(self):
        self.candidate = self.candidate_count = 0
        self.candidate_since = None
        self.last_sample = None

    def _reconcile(self, current):
        if self.owned is None:
            return None
        state = self.owned
        if state['suspended']:
            return 'Zewnetrzna zmiana A03; wylacz Smart i sprawdz nastawę'
        pending = state['pending']
        if pending is not None:
            previous = state.get('pending_previous')
            if previous is not None:
                # Wycofanie niepotwierdzonej korekty: stara baza może być
                # odczytana zanim którakolwiek komenda dotrze do urządzenia.
                # Tylko nowy potwierdzony zapis bazy zamyka tę transakcję.
                if current in (state['expected'], pending, previous):
                    return 'Czekam na potwierdzony zapis bazy po nierozstrzygnietej korekcie A03'
                state['suspended'] = True
                self._persist()
                return 'Nieoczekiwana zewnetrzna A03 podczas wycofywania korekty'
            if current == pending:
                state['expected'], state['pending'] = pending, None
                self._persist()
            elif current == state['expected']:
                return 'Czekam na potwierdzenie A03; poprzedni odczyt nie rozstrzyga komendy'
            else:
                state['suspended'] = True
                self._persist()
                return 'A03 zmieniono zewnetrznie podczas oczekiwania na potwierdzenie'
        elif current != state['expected']:
            state['suspended'] = True
            self._persist()
            return 'A03 zmieniono poza Smart; automatyka wstrzymana'
        return None

    def _write(self, target, setter, now=None):
        previous = self.owned.get('pending')
        if previous is not None and previous != target:
            self.owned.setdefault('pending_previous', previous)
        self.owned['pending'] = target
        self._persist()  # brak trwałego dziennika = brak zapisu do pompy
        self.last_attempt = time.monotonic() if now is None else now
        try:
            success = setter(target) is True
        except Exception:
            LOGGER.exception('Smart: A03 setter failed')
            success = False
        if success:
            self.owned['expected'], self.owned['pending'] = target, None
            self.owned.pop('pending_previous', None)
            self._persist()
        return success

    def _restore_owned(self, current, snap, setter, reason, now):
        if self.owned is None:
            return self._result('zwolniony', 'Smart nie posiada korekty A03')
        if not snap.can_restore or current is None:
            return self._result('przywracanie', 'Czekam na warunki przywrocenia A03: ' + reason)
        warning = self._reconcile(current)
        if self.owned['suspended']:
            return self._result('wstrzymany', warning)
        baseline = self.owned['baseline']
        # Nie gubimy pending po starym odczycie. Przy wycofywaniu wysyłamy
        # jawnie bazę po 60 s, z nowym potwierdzeniem i tą samą kolejką Modbus.
        uncertain = self.owned['pending'] is not None
        if current != baseline or uncertain:
            if self.last_attempt is not None and now - self.last_attempt < 60:
                return self._result('przywracanie', 'Odstep przed ponowieniem przywrocenia A03', base=baseline)
            if not self._write(baseline, setter, now):
                return self._result('blad', 'Nie potwierdzono przywrocenia A03; dziennik zachowany', base=baseline)
        self._release()
        return self._result('przywrocony', 'Przywrocono bazowa A03: ' + reason,
                            base=baseline, current=current, target=baseline)

    def restore_before_stage(self, cfg, snap, setter, now=None):
        now = time.monotonic() if now is None else float(now)
        with self.lock:
            try:
                if self.state_error:
                    result = self._result('blad', 'Nieczytelny dziennik A03: ' + self.state_error)
                else:
                    result = self._restore_owned(self._a03(snap.compensation), snap, setter,
                                                 'zmiana stopnia sterowania', now)
            except Exception:
                LOGGER.exception('Smart: A03 restoration failed')
                result = self._result('blad', 'Blad zapisu stanu podczas przywracania A03')
        if self.history:
            self.history.record(cfg, snap, result, evaluated=True, now_monotonic=now)
        return result

    def tick(self, cfg, snap, setter, now=None, drive_result=None):
        now = time.monotonic() if now is None else float(now)
        drive = drive_result or {}
        with self.lock:
            try:
                result = self._tick_core(cfg, snap, setter, now, drive)
            except Exception:
                LOGGER.exception('Smart: A03 state/update failed')
                result = self._result('blad', 'Blad dziennika lub obslugi A03; sprawdz historie')
        if self.history:
            self.history.record(cfg, snap, result, evaluated=result.get('evaluated', False),
                                now_monotonic=now, trend=drive.get('trend_twi_slow'))
        return result

    def _tick_core(self, cfg, snap, setter, now, drive):
        if self.state_error:
            return self._result('blad', 'Nieczytelny dziennik A03: ' + self.state_error)
        if self.last_clock is not None and now < self.last_clock:
            self._reset_observation()
            self.last_change = now if self.last_change is not None else None
            self.last_attempt = now if self.last_attempt is not None else None
        self.last_clock = now
        current = self._a03(snap.compensation)
        if self.owned and self.owned['suspended'] and not cfg.enabled and snap.can_restore:
            self._release()
            return self._result('zwolniony', 'Pozostawiono recznie zmieniona A03')
        if not cfg.enabled or not cfg.a03_live:
            if self.owned is not None:
                self._reset_observation()
                return self._restore_owned(current, snap, setter, 'Smart/A03 wylaczony', now)
            if not cfg.enabled:
                self._reset_observation()
                return self._result('wylaczony', 'Smart wylaczony')
            if not cfg.a03_live:
                self._reset_observation()
                return self._result('oczekiwanie', 'Sterowanie trybem i FLimit; zmiana kompensacji A03 wylaczona')

        restore_pending = (self.owned is not None and
                           (self.owned.get('pending_previous') is not None or
                            (self.owned['pending'] is not None and
                             self.owned['pending'] == self.owned['baseline'])))
        if self.owned is not None and (restore_pending or any(
                value is not None and value > cfg.max_compensation
                for value in (self.owned['expected'], self.owned['pending']))):
            self._reset_observation()
            return self._restore_owned(current, snap, setter,
                                       'Dokonczenie przywracania poprzedniej A03' if restore_pending else
                                       'Korekta przekracza maksymalna wartosc A03 ustawiona w Smart', now)

        hz = [_number(snap.compressor_hz, 0, 200), _number(snap.compressor_hz_second, 0, 200)]
        running = any(value is not None and value > 0 for value in hz)
        stage_ok = (snap.ready and snap.classic_enabled and snap.preset_auto and snap.auto_flimit
                    and snap.pump_on is True and snap.heat_demand is True and running
                    and str(snap.mode).lower().strip() == 'quiet' and snap.flimit_on)
        if not stage_ok or drive.get('inhibit_a03', True):
            self._reset_observation()
            reason = snap.reason or 'Brak stabilnego Quiet+FLimit / zmiana mocy'
            if self.owned is not None:
                return self._restore_owned(current, snap, setter, reason, now)
            return self._result('oczekiwanie', reason)
        values = [_number(snap.target_ch, 20, 55), _number(snap.twi, -10, 70),
                  _number(snap.two, -10, 70)]
        if current is None or any(value is None for value in values) or not -1 <= values[2] - values[1] <= 12:
            self._reset_observation()
            return self._result('pauza', 'Nieprawidlowe dane dla A03')
        baseline = self.owned['baseline'] if self.owned else current
        # Termostat ON: sam steruje zapotrzebowaniem; Smart nie analizuje Ti.
        # OFF (takze automatycznie w mrozie): brak Ti blokuje NOWE A03, ale
        # nie wstrzymuje bezpiecznej regulacji Twi/Two. Goracy pokoj wycofuje A03.
        if not snap.thermostat_enabled:
            room = _number(snap.room_temp, -10, 50) if snap.room_fresh else None
            target = _number(snap.room_target, 5, 35)
            if room is None or target is None:
                self._reset_observation()
                if self.owned:
                    return self._restore_owned(current, snap, setter, 'Brak aktualnej Ti; przywroc A03', now)
                return self._result('oczekiwanie', 'Bez wiarygodnej Ti nie zwiekszam A03')
            if room >= target - 0.05:
                self._reset_observation()
                if self.owned:
                    return self._restore_owned(current, snap, setter, 'Pokoj osiagnal nastawę', now)
                return self._result('obserwacja', 'Pokoj osiagnal nastawę; bez A03')
        if self.owned:
            warning = self._reconcile(current)
            if warning:
                return self._result('wstrzymany' if self.owned['suspended'] else 'oczekiwanie',
                                    warning, base=baseline, current=current)
        sample = _number(snap.sample_time)
        if sample is None or not 0 <= now - sample <= 30:
            self._reset_observation()
            return self._result('pauza', 'Nieaktualna probka dla A03', base=baseline, current=current)
        if not drive.get('fresh_sample', False):
            return self._result('obserwacja', 'Bez nowej probki; zachowano dotychczasowe potwierdzenia',
                                base=baseline, current=current)
        if not drive.get('a03_allowed', False):
            self._reset_observation()
            return self._result('obserwacja', 'Czekam na stabilny tryb Quiet+FLimit i trendy temperatur',
                                base=baseline, current=current)
        if self.last_sample is not None and sample <= self.last_sample:
            return self._result('obserwacja', 'Ten odczyt A03 zostal juz oceniony', base=baseline, current=current)
        self.last_sample = sample
        self.last_eval = now
        risk = drive.get('risk', 'none')
        # To heurystyka ryzyka, nie obliczenie histerezy fabrycznego stopu.
        direction = 1 if risk in ('approaching', 'high') else (-1 if current > baseline else 0)
        reason = ('Rosnie ryzyko przerwania CO mimo Quiet+FLimit' if direction > 0 else
                  'Ryzyko minelo; wycofaj dodatkowa kompensacje' if direction < 0 else
                  'Quiet+FLimit bez potrzeby A03')
        if direction == 0:
            self._reset_observation()
            return self._result('obserwacja', reason, base=baseline, current=current)
        if self.candidate != direction:
            self.candidate, self.candidate_since, self.candidate_count = direction, now, 1
        else:
            self.candidate_count += 1
        confirmation = 60 if direction > 0 else 180
        if self.candidate_count < 3 or now - self.candidate_since < confirmation:
            return self._result('obserwacja', 'Potwierdzanie: ' + reason, base=baseline, current=current)
        if self.last_change is not None and now - self.last_change < max(300, cfg.interval_min * 60):
            return self._result('obserwacja', 'Odstep miedzy korektami A03', base=baseline, current=current)
        if direction > 0 and current >= cfg.max_compensation:
            return self._result('obserwacja', 'Osiagnieto maksymalna wartosc kompensacji A03 w Smart',
                                base=baseline, current=current)
        # Limit jest bezwzgledna wartoscia A03, nigdy dodatkiem do recznej nastawy.
        # Recznej bazy nie obnizamy, nawet jesli jest wyzsza od limitu Smart.
        wanted = (min(cfg.max_compensation, _step(current + 0.5)) if direction > 0 else
                  max(baseline, _step(current - 0.5)))
        if wanted == current:
            return self._result('obserwacja', 'Bez potrzeby zmiany A03', base=baseline, current=current)
        if self.owned is None:
            self.owned = dict(baseline=current, expected=current, pending=None, suspended=False)
        if not self._write(wanted, setter, now):
            return self._result('blad', 'Brak potwierdzenia A03; zachowano pending do uzgodnienia',
                                base=baseline, current=current, target=wanted, evaluated=True)
        self.last_change = now
        self._reset_observation()
        if wanted == baseline:
            self._release()
        return self._result('korekta', reason, base=baseline, current=current, target=wanted, evaluated=True)

    def coordinate(self, drive, cfg, snap, set_mode, set_flimit, set_a03, now=None, set_stage=None):
        """Jeden właściciel decyzji: tryb/FLimit, potem opcjonalna A03.

        Przy zwiększaniu mocy A03 musi zostać wycofana. Flaga inhibit_a03
        utrzymuje tę kolejność również w przerwie pomiędzy świeżymi ramkami.
        """
        if self.state_error or (self.owned or {}).get('suspended'):
            drive.reset()
            power = dict(status='pauza', reason='Stan A03 wymaga wyjasnienia',
                         evaluated=False, inhibit_a03=True, a03_allowed=False)
        else:
            power = drive.tick(cfg, snap, set_mode, set_flimit, set_stage=set_stage,
                               a03_owned=self.owned is not None, now=now)
        if self.history:
            self.history.record_stage(cfg, snap, power, now_monotonic=now)
        if power['status'] == 'przywroc_a03':
            compensation = self.restore_before_stage(cfg, snap, set_a03, now=now)
        elif power['status'] in ('zmiana_trybu', 'zmiana_flimit'):
            compensation = self._result('obserwacja', 'Potwierdzono zmiane stopnia; oczekiwanie na nowe dane')
        else:
            compensation = self.tick(cfg, snap, set_a03, now=now, drive_result=power)
        return power, compensation


