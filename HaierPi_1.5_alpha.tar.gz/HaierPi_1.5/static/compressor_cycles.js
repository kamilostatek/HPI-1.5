// Read-only compressor history. Missing data never becomes a zero count.
(function () {
  'use strict';

  function initialize() {
    const card = document.getElementById('compressor-cycles-card');
    if (!card) return;
    const periods = ['24h', '7d'];
    const rows = {
      starts: 'compressor_starts',
      co: 'co_cycles',
      cwu: 'cwu_cycles',
      cycling: 'cycling_restarts',
      defrosts: 'defrosts'
    };
    const fallback = {
      'cycles.incomplete': 'Dane niepełne',
      'cycles.tracking_since': 'Zbieranie danych od {{date}}.',
      'cycles.waiting': 'Czekam na dane o cyklach.',
      'cycles.stale': 'Brak świeżych odczytów pompy. Liczniki obejmują dotychczas zarejestrowane zdarzenia.',
      'cycles.error': 'Nie można odświeżyć liczników.',
      'cycles.last_values': 'Wyświetlono ostatnio odczytane wartości.',
      'cycles.truncated': 'Część starszej historii jest niedostępna; niepełne okresy są oznaczone w tabeli.'
    };
    let lastData = null;
    let state = 'waiting';
    let refreshTimer = null;
    let activeRequest = null;

    function translated(key, variables) {
      const options = Object.assign({defaultValue: fallback[key] || key}, variables || {});
      try {
        if (window.i18next && typeof window.i18next.t === 'function') {
          const value = window.i18next.t(key, options);
          if (typeof value === 'string') return value;
        }
      } catch (error) { /* Preserve the readable fallback when translations are offline. */ }
      let value = options.defaultValue;
      Object.keys(variables || {}).forEach(name => {
        value = value.split('{{' + name + '}}').join(String(variables[name]));
      });
      return value;
    }

    function setText(id, value) {
      const element = document.getElementById(id);
      if (element) element.textContent = value;
    }

    function formatDate(timestamp) {
      const locale = window.i18next && window.i18next.language;
      try {
        return new Intl.DateTimeFormat(locale || undefined, {
          dateStyle: 'short', timeStyle: 'short'
        }).format(new Date(timestamp * 1000));
      } catch (error) {
        return new Date(timestamp * 1000).toLocaleString();
      }
    }

    function validData(data) {
      return data && data.available === true &&
        typeof data.started_at === 'number' && Number.isFinite(data.started_at) &&
        data.started_at > 0 && data.windows && periods.every(period => {
          const values = data.windows[period];
          return values && Object.values(rows).every(key =>
            typeof values[key] === 'number' && Number.isSafeInteger(values[key]) && values[key] >= 0);
        });
    }

    function render() {
      if (lastData) {
        periods.forEach(period => {
          const values = lastData.windows[period];
          Object.entries(rows).forEach(([row, key]) => {
            setText('cycles-' + row + '-' + period, String(values[key]));
          });
          setText('cycles-coverage-' + period,
            values.complete === true ? '' : translated('cycles.incomplete'));
        });
        setText('cycles-tracking-since', translated('cycles.tracking_since', {
          date: formatDate(lastData.started_at)
        }));
      }

      const messages = [];
      if (state === 'error') {
        messages.push(translated('cycles.error'));
        if (lastData) messages.push(translated('cycles.last_values'));
      } else if (state === 'stale') {
        messages.push(translated('cycles.stale'));
      } else if (!lastData || state === 'waiting') {
        messages.push(translated('cycles.waiting'));
        if (lastData) messages.push(translated('cycles.last_values'));
      }
      if (lastData && lastData.history_truncated) messages.push(translated('cycles.truncated'));
      setText('cycles-message', messages.join(' '));
    }

    function refreshTooltips() {
      card.querySelectorAll('[data-cycle-tooltip]').forEach(element => {
        const key = element.getAttribute('data-cycle-tooltip');
        const previous = element.getAttribute('data-bs-title') || '';
        const title = translated(key, {defaultValue: previous});
        try {
          if (window.bootstrap && window.bootstrap.Tooltip) {
            const instance = window.bootstrap.Tooltip.getInstance(element);
            if (instance) instance.dispose();
          }
          element.setAttribute('data-bs-title', title);
          if (window.bootstrap && window.bootstrap.Tooltip) {
            new window.bootstrap.Tooltip(element);
          } else {
            element.setAttribute('title', title);
          }
        } catch (error) { /* The description remains available as a native title. */
          element.setAttribute('title', title);
        }
      });
    }

    function schedule() {
      window.clearTimeout(refreshTimer);
      refreshTimer = null;
      if (!document.hidden) refreshTimer = window.setTimeout(refresh, 60000);
    }

    async function refresh() {
      if (document.hidden || activeRequest) return;
      window.clearTimeout(refreshTimer);
      const request = {controller: new AbortController()};
      activeRequest = request;
      const timeout = window.setTimeout(() => request.controller.abort(), 15000);
      try {
        const response = await fetch(card.getAttribute('data-endpoint'), {
          method: 'GET', credentials: 'same-origin', cache: 'no-store',
          headers: {Accept: 'application/json'}, signal: request.controller.signal
        });
        if (!response.ok || response.redirected) throw new Error('Statistics unavailable');
        const data = await response.json();
        if (activeRequest !== request || document.hidden) return;
        if (validData(data)) {
          lastData = data;
          state = data.status === 'stale' ? 'stale' : 'ok';
        } else if (data && data.status === 'waiting' && data.started_at == null) {
          state = 'waiting';
        } else {
          throw new Error('Invalid statistics response');
        }
        render();
      } catch (error) {
        if (activeRequest === request && !document.hidden) {
          state = 'error';
          render();
        }
      } finally {
        window.clearTimeout(timeout);
        if (activeRequest === request) {
          activeRequest = null;
          schedule();
        }
      }
    }

    document.addEventListener('visibilitychange', () => {
      window.clearTimeout(refreshTimer);
      refreshTimer = null;
      if (document.hidden) {
        const previous = activeRequest;
        activeRequest = null;
        if (previous) previous.controller.abort();
      } else {
        refresh();
      }
    });

    if (window.i18next && typeof window.i18next.on === 'function') {
      const languageReady = () => window.setTimeout(() => {
        render();
        refreshTooltips();
      }, 0);
      window.i18next.on('initialized', languageReady);
      window.i18next.on('languageChanged', languageReady);
    }
    render();
    refreshTooltips();
    refresh();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize, {once: true});
  } else {
    initialize();
  }
})();
