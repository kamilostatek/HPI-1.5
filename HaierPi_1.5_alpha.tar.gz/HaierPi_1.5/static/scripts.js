/*!
* Start Bootstrap - Simple Sidebar v6.0.6 (https://startbootstrap.com/template/simple-sidebar)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-simple-sidebar/blob/master/LICENSE)
*/
//
// Scripts
//

function translateElement(id) {
    const element = document.getElementById(id);
    if (!element) return;

    // Gdy CDN jest niedostępny, pozostaw oryginalny tekst bez błędu JS.
    if (!window.i18next || typeof window.i18next.t !== "function") return;

    // Początkowe tłumaczenie po załadowaniu strony
    let lastValue = element.textContent.trim();
    element.textContent = i18next.t(lastValue);

    // Obserwowanie zmian i dynamiczne tłumaczenie
    const observer = new MutationObserver((mutationsList) => {
        for (let mutation of mutationsList) {
            if (mutation.type === "childList") {
                let newValue = element.textContent.trim();
                
                // Zapobieganie zapętleniu - zmieniamy tylko, gdy wartość się zmienia
                if (newValue !== lastValue) {
                    lastValue = newValue;

                    // Wyłączamy obserwator na czas aktualizacji tekstu
                    observer.disconnect();
                    element.textContent = i18next.t(newValue);
                    
                    // Włączamy ponownie po zmianie
                    observer.observe(element, { childList: true, subtree: true });
                }
            }
        }
    });

    observer.observe(element, { childList: true, subtree: true });
}


window.addEventListener('DOMContentLoaded', event => {

    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        // Uncomment Below to persist sidebar toggle between refreshes
        // if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
        //     document.body.classList.toggle('sb-sidenav-toggled');
        // }
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            try {
                localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
            } catch (e) {
                // Nie blokuj rozwijania menu, gdy przeglądarka blokuje localStorage.
            }
        });
    }

});

$(document).ready(function() {
    // Emoji flags are not available on some desktop setups; use SVG assets for consistency.
    const langFlags = {
        "en": "/static/flags/en.svg",
        "pl": "/static/flags/pl.svg",
        "nl": "/static/flags/nl.svg"
    };

    function getLocalStorageItem(key) {
        try { return localStorage.getItem(key); } catch (e) { return null; }
    }

    function setLocalStorageItem(key, value) {
        try { localStorage.setItem(key, value); } catch (e) { /* localStorage może być wyłączony */ }
    }

    let browserLang = String(navigator.language || navigator.userLanguage || 'en').toLowerCase().split('-')[0];
    if (!Object.prototype.hasOwnProperty.call(langFlags, browserLang)) browserLang = 'en';

    let savedLang = getLocalStorageItem('i18next') || browserLang;
    if (!Object.prototype.hasOwnProperty.call(langFlags, savedLang)) savedLang = browserLang;
    $("#current-lang-flag").attr("src", langFlags[savedLang]).attr("alt", savedLang.toUpperCase());

    // Strona nie może pozostać ukryta, gdy CDN i18next działa tylko częściowo
    // albo odpowiedź z backendu tłumaczeń jest opóźniona.
    let panelVisible = false;
    function revealPanel(animated) {
        if (panelVisible) return;
        panelVisible = true;
        if (animated) $('body').fadeIn(500);
        else $('body').show();
    }
    window.setTimeout(function() { revealPanel(false); }, 4000);

    if (window.i18next && window.i18nextHttpBackend && window.jqueryI18next) {
        try {
            i18next.use(i18nextHttpBackend).init({
                lng: savedLang,
                fallbackLng: 'en',
                debug: false,
                backend: { loadPath: '/static/locales/{{lng}}/translation.json' }
            }, function(err) {
                if (err) console.warn('i18next: nie udało się w pełni załadować tłumaczeń', err);
                try {
                    jqueryI18next.init(i18next, $);
                    $('body').localize();
                } catch (e) {
                    console.warn('i18next: tłumaczenia niedostępne', e);
                }
                revealPanel(true);
            });
        } catch (e) {
            console.warn('i18next: błąd inicjalizacji', e);
            revealPanel(false);
        }
    } else {
        // Brak bibliotek i18n z CDN: panel pozostaje dostępny bez tłumaczeń JS.
        console.warn('i18next offline — brak części tłumaczeń dynamicznych');
        revealPanel(false);
    }

    // Obsługa zmiany języka i zapisywanie do localStorage
    $(".lang-selector").on("click", function() {
	    console.log($(this).data("lang"));
        let newLang = $(this).data("lang");
        setLocalStorageItem('i18next', newLang);
     //   location.reload(); // Przeładowanie, aby zastosować nowy język
    });
//});
function refreshTooltips() {
        // Usunięcie istniejących tooltipów
        $('[data-bs-toggle="tooltip"]').each(function() {
            let tooltipInstance = bootstrap.Tooltip.getInstance(this);
            if (tooltipInstance) {
                tooltipInstance.dispose(); // Usuń istniejący tooltip
            }
        });

        // Korzystamy z Bootstrap 5 bez kolizji z jQuery UI.
        if (!window.bootstrap || !bootstrap.Tooltip) return;
        $('[data-bs-toggle="tooltip"]').each(function() {
            // Podpowiedzi dostepne rowniez dotykiem i klawiatura.
            if (!this.hasAttribute('tabindex')) this.setAttribute('tabindex', '0');
            if (!this.hasAttribute('role') && this.tagName.toLowerCase() === 'i') this.setAttribute('role', 'button');
            bootstrap.Tooltip.getOrCreateInstance(this, {
                container: 'body', trigger: 'hover focus click', boundary: document.body
            });
        });
    }
            function changeLanguage(lang) {
                if (!window.i18next || typeof i18next.changeLanguage !== 'function') return;
                i18next.changeLanguage(lang, function() {
                    $('body').localize();
                    document.cookie = "i18next=" + lang + "; path=/";
		    $("#current-lang-flag").attr("src", langFlags[lang]).attr("alt", lang.toUpperCase()); // Zmień flagę w menu
		    refreshTooltips();
                });
            }
            $('#lang-pl').click(function() { changeLanguage('pl'); });
            $('#lang-en').click(function() { changeLanguage('en'); });
	    $('#lang-nl').click(function() { changeLanguage('nl'); });
            // R4 uruchamial opisy dopiero po zmianie jezyka.
            refreshTooltips();
        });


/*!
 * Color mode toggler for Bootstrap's docs (https://getbootstrap.com/)
 * Copyright 2011-2024 The Bootstrap Authors
 * Licensed under the Creative Commons Attribution 3.0 Unported License.
 */

(() => {
  'use strict'
  const getStoredTheme = () => {
    try { return localStorage.getItem('theme') } catch (e) { return null }
  }
  const setStoredTheme = theme => {
    try { localStorage.setItem('theme', theme) } catch (e) { /* prywatny tryb przeglądarki */ }
  }

  const getPreferredTheme = () => {
    const storedTheme = getStoredTheme()
    if (storedTheme) {
      return storedTheme
    }

    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
  }

  const setTheme = theme => {
    if (theme === 'auto') {
      document.documentElement.setAttribute('data-bs-theme', (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'))
    } else {
      document.documentElement.setAttribute('data-bs-theme', theme)
    }
  }

  setTheme(getPreferredTheme())

  const showActiveTheme = (theme, focus = false) => {
    const themeSwitcher = document.querySelector('#bd-theme')

    if (!themeSwitcher) {
      return
    }
    const themeSwitcherText = document.querySelector('#bd-theme-text')
    const activeThemeIcon = document.querySelector('.theme-icon-active use')
    const btnToActive = document.querySelector(`[data-bs-theme-value="${theme}"]`)
    const svgOfActiveBtn = btnToActive.querySelector('svg use').getAttribute('href')

    document.querySelectorAll('[data-bs-theme-value]').forEach(element => {
      element.classList.remove('active')
      element.setAttribute('aria-pressed', 'false')
    })
    btnToActive.classList.add('active')
    btnToActive.setAttribute('aria-pressed', 'true')
    activeThemeIcon.setAttribute('href', svgOfActiveBtn)
    const themeSwitcherLabel = `${themeSwitcherText.textContent} (${btnToActive.dataset.bsThemeValue})`
    themeSwitcher.setAttribute('aria-label', themeSwitcherLabel)
    if (focus) {
      themeSwitcher.focus()
    }
  }

  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    const storedTheme = getStoredTheme()
    if (storedTheme !== 'light' && storedTheme !== 'dark') {
      setTheme(getPreferredTheme())
    }
  })

  window.addEventListener('DOMContentLoaded', () => {
    showActiveTheme(getPreferredTheme())

    document.querySelectorAll('[data-bs-theme-value]')
      .forEach(toggle => {
        toggle.addEventListener('click', () => {
          const theme = toggle.getAttribute('data-bs-theme-value')
          setStoredTheme(theme)
          setTheme(theme)
          showActiveTheme(theme, true)
        })
      })
  })
})()
const alertPlaceholder = document.getElementById('liveAlertPlaceholder');

const appendAlert = (message, type, timeout = 2000, addi = "") => {
    if (!alertPlaceholder) return;
    const wrapper = document.createElement('div');
    // Zewnętrzne komunikaty i dane pochodzące z serwera są tekstem, nie HTML.
    // Także klasę alertu ograniczamy do prawidłowych wartości Bootstrapa.
    const safeType = ['success', 'danger', 'warning', 'info'].includes(type) ? type : 'info';
    const progressBarColors = {
        success: '#0f5132',
        danger: '#842029',
        warning: '#664d03',
        info: '#055160'
    };
    const progressBarColor = progressBarColors[safeType];
    const translatedMessage = (window.i18next && typeof i18next.exists === 'function' && i18next.exists(String(message)))
        ? i18next.t(String(message)) : String(message);
    if (safeType === 'warning') timeout = 10000;
    else if (safeType === 'danger') timeout = 0;

    wrapper.innerHTML = `
        <div class="alert alert-${safeType} alert-dismissible fade show" role="alert">
            <div class="hpi-alert-message"></div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            ${timeout > 0 ? `<div class="progress-bar-striped progress-bar-animated" style="height: 5px; background: ${progressBarColor}; width: 100%;"></div>` : ''}
        </div>
    `;
    wrapper.querySelector('.hpi-alert-message').textContent = [translatedMessage, addi].filter(Boolean).join(' ');
    alertPlaceholder.append(wrapper);

    if (timeout > 0) {
        let progressBar = wrapper.querySelector('.progress-bar-striped');
        let width = 100;
        let interval = setInterval(() => {
            width -= 100 / (timeout / 100); // Skaluje animację zgodnie z czasem
            progressBar.style.width = width + '%';
            if (width <= 0) {
                clearInterval(interval);
                wrapper.remove();
            }
        }, 100);
    }
};
