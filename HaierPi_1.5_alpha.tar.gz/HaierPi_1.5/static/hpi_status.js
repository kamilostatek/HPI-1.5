// Navbar HPi service status (LED + tooltip)
// Polls backend /api/hpi_status and renders:
// - OK (service + recent pump frame): blue diode
// - No fresh pump frame: amber diode (service still running)
// - Backend/thread failure: blinking red diode
// - Unknown/loading: grey
// Tooltip UX (per request):
// - click on the HPi pill -> show/hide tooltip
// - leaving the pill -> hide tooltip
// - no live content updates while tooltip is open (prevents disappearing on refresh)
//
// Extra UX (requested):
// - if an ERROR is detected (red blinking), the HPi pill becomes visible automatically

document.addEventListener("DOMContentLoaded", () => {
  const pill = document.getElementById("hpi-status-pill");
  const led = document.getElementById("hpi-status-led");
  if (!pill || !led) return;

  const DEFAULT_RX_AGE_S = 15; // fallback for an older backend

  // --- Tooltip (single instance, manual) ---
  let tipInst = null;
  let tipShown = false;
  let lastTipHtml = "HPi: sprawdzanie...";

  // When true, we keep the pill visible (used for ERROR auto-reveal)
  let forcedVisible = false;

  function setLed(state) {
    led.classList.remove("hpi-led-ok", "hpi-led-warn", "hpi-led-err", "hpi-led-unknown");
    pill.classList.remove("hpi-state-warn", "hpi-state-err");
    if (state === "ok") led.classList.add("hpi-led-ok");
    else if (state === "warn") {
      led.classList.add("hpi-led-warn");
      pill.classList.add("hpi-state-warn");
    } else if (state === "err") {
      led.classList.add("hpi-led-err");
      pill.classList.add("hpi-state-err");
    } else led.classList.add("hpi-led-unknown");
  }

  function keepPillVisible() {
    pill.classList.add("hpi-reveal");
    window.clearTimeout(revealPill._t);
  }

  function updateVisibility() {
    // keep visible if:
    // - forcedVisible (ERROR)
    // - tooltip open (user is reading)
    if (forcedVisible || tipShown) {
      keepPillVisible();
    } else {
      pill.classList.remove("hpi-reveal");
    }
  }

  function revealPill(ms = 2500) {
    pill.classList.add("hpi-reveal");
    window.clearTimeout(revealPill._t);

    // If ERROR is active or tooltip is open, never auto-hide
    if (forcedVisible || tipShown) return;

    if (ms > 0) {
      revealPill._t = window.setTimeout(() => {
        if (!forcedVisible && !tipShown) pill.classList.remove("hpi-reveal");
      }, ms);
    }
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function toHtml(text) {
    return escapeHtml(text).replace(/\n/g, "<br>");
  }

  function ensureTooltip() {
    if (tipInst) return tipInst;
    if (!window.bootstrap || !bootstrap.Tooltip) return null;
    try {
      tipInst = new bootstrap.Tooltip(pill, {
        trigger: "manual",
        html: true,
        placement: "bottom",
        customClass: "hpi-tooltip",
        // Use a function so Bootstrap reads current content on each .show()
        title: () => lastTipHtml,
      });
      return tipInst;
    } catch (e) {
      return null;
    }
  }

  function setTooltipText(text) {
    // Always update stored content, but DO NOT push updates into an open tooltip.
    lastTipHtml = toHtml(text);
    if (!tipShown) {
      // keep attributes in sync for the next show()
      pill.setAttribute("data-bs-title", lastTipHtml);
      pill.setAttribute("data-bs-original-title", lastTipHtml);
    }
  }

  function showTooltip() {
    const inst = ensureTooltip();
    if (!inst) return;

    // Sync attributes right before show (Bootstrap may read them)
    pill.setAttribute("data-bs-title", lastTipHtml);
    pill.setAttribute("data-bs-original-title", lastTipHtml);

    // Keep pill visible while tooltip is open
    tipShown = true;
    updateVisibility();

    try {
      inst.show();
    } catch (e) {
      tipShown = false;
      updateVisibility();
    }
  }

  function hideTooltip() {
    if (!tipInst) {
      tipShown = false;
      updateVisibility();
      return;
    }
    try {
      tipInst.hide();
    } catch (e) {
      // ignore
    }
    tipShown = false;
    updateVisibility();

    // after hide we can safely apply current content for the next click
    pill.setAttribute("data-bs-title", lastTipHtml);
    pill.setAttribute("data-bs-original-title", lastTipHtml);
  }

  pill.addEventListener("click", (e) => {
    e.preventDefault();
    // Reveal briefly even if OK (nice on touch), but ERROR/tooltips will override auto-hide
    revealPill(3000);
    if (tipShown) hideTooltip();
    else showTooltip();
  });

  // Hide as soon as the cursor leaves the pill
  pill.addEventListener("mouseleave", () => {
    if (tipShown) hideTooltip();
  });

  // Hide on outside click (useful for touch)
  document.addEventListener("pointerdown", (e) => {
    if (!tipShown) return;
    if (!pill.contains(e.target)) hideTooltip();
  });

  // Hide on ESC
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && tipShown) hideTooltip();
  });

  function fmtAge(age) {
    if (age === null || age === undefined) return "brak";
    const n = Number(age);
    if (!Number.isFinite(n)) return "brak";
    return n.toFixed(1) + " s";
  }

  function fmtBool(v) {
    if (v === null || v === undefined) return "—";
    return v ? "OK" : "ERR";
  }

  async function poll() {
    try {
      const r = await fetch("/api/hpi_status", { cache: "no-store" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      const j = await r.json();

      const dead = Number(j.dead ?? 0);
      const bgOk = !!(j.threads && j.threads.bg);
      const serialOk = !!(j.threads && j.threads.serial);
      const mqttEnabled = !!(j.threads && j.threads.mqtt_enabled);
      const mqtt = (j.threads && j.threads.mqtt !== undefined) ? j.threads.mqtt : null;
      // When MQTT is disabled, treat it as OK for the overall status.
      const mqttOk = (!mqttEnabled) ? true : !!mqtt;

      const rx = j.pump_rx || {};
      const age = (rx.age_s !== undefined) ? rx.age_s : null;
      const block = rx.block || "—";
      const errTxt = rx.last_error ? String(rx.last_error).split("\n")[0] : "";
      const maxAge = Number(rx.max_age_s) > 0 ? Number(rx.max_age_s) : DEFAULT_RX_AGE_S;
      const ageNum = (age === null || age === undefined) ? NaN : Number(age);
      const hasFrame = Number.isFinite(ageNum) && ageNum >= 0;
      // New backend provides the authoritative freshness check; fallback stays safe.
      const pumpOk = (typeof rx.fresh === "boolean") ? rx.fresh :
        (hasFrame && ageNum <= maxAge);
      const serviceOk = (typeof j.service_ok === "boolean") ? j.service_ok :
        ((dead === 0) && bgOk && serialOk && mqttOk);
      const state = !serviceOk ? "err" : (pumpOk ? "ok" : "warn");

      setLed(state);

      // When the pump is missing, keep the warning visible as with backend errors.
      forcedVisible = state !== "ok";
      updateVisibility();

      let tip = state === "ok" ? "HPi: OK" :
        (state === "warn" ? "HPi: BRAK KOMUNIKACJI Z POMPĄ" : "HPi: BŁĄD USŁUGI");
      tip += `\nBackground: ${fmtBool(bgOk)}`;
      tip += `\nSerial (wątek): ${fmtBool(serialOk)}`;
      if (mqttEnabled) tip += `\nMQTT: ${fmtBool(!!mqtt)}`;
      else tip += "\nMQTT: wyłączony";
      tip += `\nPompa: ${pumpOk ? "OK" : (hasFrame ? "brak aktualnych danych" : "brak odebranych ramek")}`;
      tip += `\n• Odczyt: Ostatnia ramka ${block}, Wiek: ${fmtAge(age)}`;
      if (dead !== 0) tip += `\n• DEAD=${dead}`;
      if (state !== "ok" && errTxt) tip += `\n• last_error: ${errTxt}`;

      setTooltipText(tip);
    } catch (e) {
      setLed("err");

      // Requested behavior: if backend is down, also auto-show pill
      forcedVisible = true;
      updateVisibility();

      setTooltipText("HPi: brak połączenia z backendem\n" + String(e));
    }
  }

  // Mobile hint: reveal pill briefly on touch
  pill.addEventListener("pointerdown", () => revealPill(3000));

  poll();
  window.setInterval(poll, 1500);
});
