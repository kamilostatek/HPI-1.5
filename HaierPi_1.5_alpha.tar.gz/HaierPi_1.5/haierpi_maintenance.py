"""HaierPi 1.5: lokale kopie, sesje oraz raporty awarii.

Modul nie importuje Flask ani sterownikow sprzetowych. Nowe pliki .hpi sa
archiwami ZIP; starsze kopie 7z sa obslugiwane przy zainstalowanym 7zr.
"""

import configparser
import io
import json
import os
from pathlib import Path
import secrets
import stat
import subprocess
import tempfile
import zipfile

MAX_BACKUP_BYTES = 8 * 1024 * 1024
MAX_MEMBER_BYTES = 2 * 1024 * 1024
MEMBERS = ("config.ini", "schedule_ch.json", "schedule_dhw.json")
SEVEN_ZIP_MAGIC = b"7z\xbc\xaf\x27\x1c"


class BackupError(ValueError):
    """Niewlasciwa lub uszkodzona kopia zapasowa."""


def get_or_create_session_secret(haier_dir="/opt/haier"):
    """Pobiera trwaly sekret aplikacji (lub jawnie podany przez administratora)."""
    configured = os.environ.get("HAIERPI_SECRET_KEY")
    if configured:
        if len(configured) < 32:
            raise ValueError("HAIERPI_SECRET_KEY musi miec co najmniej 32 znaki")
        return configured

    directory = Path(haier_dir)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / ".session_secret"
    try:
        flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        descriptor = os.open(str(path), flags, 0o600)
    except FileExistsError:
        pass
    else:
        with os.fdopen(descriptor, "w", encoding="ascii") as output:
            output.write(secrets.token_hex(32) + "\n")
            output.flush()
            os.fsync(output.fileno())

    # Klucz nigdy nie moze byc linkiem ani zwyklym plikiem publicznym.
    metadata = path.lstat()
    if not stat.S_ISREG(metadata.st_mode):
        raise RuntimeError("Plik sekretu sesji nie jest zwyklym plikiem")
    if stat.S_IMODE(metadata.st_mode) != 0o600:
        os.chmod(path, 0o600)
    secret = path.read_text(encoding="ascii").strip()
    if len(secret) < 32:
        raise RuntimeError("Nieprawidlowy klucz sesji")
    return secret


def build_backup(haier_dir="/opt/haier", config_path="/opt/config.ini"):
    """Buduje bezpieczne, przenosne .hpi (ZIP) z rzeczywistego /opt/config.ini."""
    directory = Path(haier_dir)
    config = Path(config_path)
    if not config.is_file():
        raise BackupError("Brak pliku konfiguracji /opt/config.ini")
    members = [("config.ini", config)]
    for name in MEMBERS[1:]:
        candidate = directory / name
        if candidate.is_file() and not candidate.is_symlink():
            members.append((name, candidate))

    output = io.BytesIO()
    with zipfile.ZipFile(output, mode="w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=6) as archive:
        for name, path in members:
            # Czytamy z limitem, aby kopia nie wyczerpala pamieci urzadzenia.
            with path.open("rb") as source:
                data = source.read(MAX_MEMBER_BYTES + 1)
            if len(data) > MAX_MEMBER_BYTES:
                raise BackupError("Plik do kopii jest zbyt duzy: " + name)
            archive.writestr(name, data)
    result = output.getvalue()
    if len(result) > MAX_BACKUP_BYTES:
        raise BackupError("Kopia zapasowa przekracza limit")
    return result


def _read_legacy_7z(raw, directory):
    """Wyodrebnia tylko dozwolone nazwy z archiwum starego typu.

    Nie wolno uruchamiac powloki ani uzywac nazwy pliku z formularza w poleceniu.
    """
    with tempfile.TemporaryDirectory(prefix="haierpi-legacy-", dir=directory) as scratch:
        root = Path(scratch)
        archive_path = root / "backup.7z"
        archive_path.write_bytes(raw)
        out = root / "extracted"
        out.mkdir()
        # 7zr wystepuje na instalacjach HaierPi ze starymi kopiami 7z.
        def limit_extract():
            # Limit rozmiaru pojedynczego pliku i czasu CPU procesu 7zr.
            import resource
            resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_MEMBER_BYTES, MAX_MEMBER_BYTES))
            resource.setrlimit(resource.RLIMIT_CPU, (20, 20))

        try:
            process = subprocess.run(
                ["7zr", "e", "-y", "-aoa", "-o" + str(out), str(archive_path), *MEMBERS],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=25, check=False,
                preexec_fn=limit_extract,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            raise BackupError("Przywracanie starej kopii wymaga dostepnego polecenia 7zr") from exc
        # 7z moze zwrocic kod 1 przy braku opcjonalnego harmonogramu.
        if process.returncode not in (0, 1):
            raise BackupError("Nie udalo sie odczytac starego archiwum 7z")
        result = {}
        for name in MEMBERS:
            path = out / name
            if not path.is_file() or path.is_symlink():
                continue
            with path.open("rb") as source:
                data = source.read(MAX_MEMBER_BYTES + 1)
            if len(data) > MAX_MEMBER_BYTES:
                raise BackupError("Plik archiwum jest zbyt duzy: " + name)
            result[name] = data
        return result


def _read_zip(raw):
    result = {}
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            entries = archive.infolist()
            names = [info.filename for info in entries]
            if len(names) != len(set(names)) or any(name not in MEMBERS for name in names):
                raise BackupError("Archiwum zawiera niedozwolone lub powtorzone pliki")
            if sum(info.file_size for info in entries) > MAX_MEMBER_BYTES * len(MEMBERS):
                raise BackupError("Archiwum ma zbyt duza laczna wielkosc")
            for info in entries:
                if info.is_dir() or info.file_size > MAX_MEMBER_BYTES:
                    raise BackupError("Niedozwolona pozycja archiwum: " + info.filename)
                unix_mode = (info.external_attr >> 16) & 0xFFFF
                if stat.S_IFMT(unix_mode) == stat.S_IFLNK:
                    raise BackupError("Archiwum zawiera dowiazanie symboliczne")
                with archive.open(info, "r") as stream:
                    data = stream.read(MAX_MEMBER_BYTES + 1)
                if len(data) > MAX_MEMBER_BYTES:
                    raise BackupError("Plik archiwum jest zbyt duzy")
                result[info.filename] = data
    except (zipfile.BadZipFile, RuntimeError, EOFError, OSError) as exc:
        raise BackupError("Nie mozna odczytac archiwum ZIP") from exc
    return result


def _validate_members(files):
    if "config.ini" not in files:
        raise BackupError("W kopii brak config.ini")
    config = configparser.ConfigParser(interpolation=None)
    try:
        config.read_string(files["config.ini"].decode("utf-8-sig"))
    except (UnicodeError, configparser.Error) as exc:
        raise BackupError("Nieprawidlowy format config.ini") from exc
    if not config.has_section("MAIN") or not config.has_section("SETTINGS"):
        raise BackupError("config.ini nie zawiera wymaganych sekcji MAIN i SETTINGS")
    for name in MEMBERS[1:]:
        if name not in files:
            continue
        try:
            data = json.loads(files[name].decode("utf-8-sig"))
        except (UnicodeError, ValueError) as exc:
            raise BackupError("Bledny JSON w " + name) from exc
        if not isinstance(data, list) or len(data) > 7:
            raise BackupError("Nieprawidlowy harmonogram w " + name)


def restore_backup(source, filename, haier_dir="/opt/haier",
                   config_path="/opt/config.ini"):
    """Sprawdza cala kopie przed zapisaniem ustawien i harmonogramow.

    Zwraca liste odtworzonych nazw. Brakujace harmonogramy pozostaja bez zmian.
    """
    if not filename or not filename.lower().endswith(".hpi"):
        raise BackupError("Dozwolone sa tylko pliki .hpi")
    raw = source.read(MAX_BACKUP_BYTES + 1)
    if len(raw) > MAX_BACKUP_BYTES:
        raise BackupError("Archiwum przekracza 8 MB")
    if not raw:
        raise BackupError("Przeslano pusty plik")

    directory = Path(haier_dir)
    if raw.startswith(SEVEN_ZIP_MAGIC):
        directory.mkdir(parents=True, exist_ok=True)
        files = _read_legacy_7z(raw, directory)
    else:
        files = _read_zip(raw)
    _validate_members(files)

    destinations = {"config.ini": Path(config_path)}
    destinations.update({name: directory / name for name in MEMBERS[1:]})
    staged = []
    try:
        # Etap przygotowania: zadnego pliku nie nadpisujemy przed pelna walidacja.
        for name, data in files.items():
            target = destinations[name]
            target.parent.mkdir(parents=True, exist_ok=True)
            descriptor, path = tempfile.mkstemp(prefix=".haierpi-restore-", dir=target.parent)
            staged.append((Path(path), target))
            with os.fdopen(descriptor, "wb") as dest:
                os.fchmod(dest.fileno(), 0o600)
                dest.write(data)
                dest.flush()
                os.fsync(dest.fileno())
        # Zastapienia atomowe dla pojedynczych plikow (na tym samym systemie plikow).
        for temporary, target in staged:
            os.replace(temporary, target)
        return [name for name in MEMBERS if name in files]
    finally:
        for temporary, _ in staged:
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass


def write_local_crash_report(haier_dir="/opt/haier", *, service="haier.service",
                             timestamp=None):
    """Zapisuje ograniczony raport journalctl do lokalnego pliku, bez uploadu."""
    from datetime import datetime
    directory = Path(haier_dir) / "logs"
    directory.mkdir(parents=True, exist_ok=True)
    stamp = timestamp or datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    path = directory / ("crashlog-" + stamp + ".log")
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    with os.fdopen(os.open(str(path), flags, 0o600), "w", encoding="utf-8") as dest:
        try:
            subprocess.run(
                ["journalctl", "-u", service, "-p", "debug", "-n", "500",
                 "--no-pager", "-o", "short-iso"],
                stdout=dest, stderr=subprocess.STDOUT, timeout=15, check=False,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            dest.write("journalctl nie jest dostepny: " + str(exc) + "\n")
    return path
